package hats.client.core;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent.ClientTickEvent;
import cpw.mods.fml.common.gameevent.TickEvent.Phase;
import cpw.mods.fml.common.gameevent.TickEvent.RenderTickEvent;
import hats.api.RenderOnEntityHelper;
import hats.client.gui.GuiHatSelection;
import hats.client.gui.GuiHatUnlocked;
import hats.client.gui.GuiTradeReq;
import hats.common.Hats;
import hats.common.core.HatHandler;
import hats.common.core.HatInfo;
import hats.common.entity.EntityHat;
import hats.common.packet.PacketPing;
import hats.common.packet.PacketRequestMobHats;
import ichun.common.core.network.PacketHandler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;
import org.lwjgl.input.Keyboard;

public class TickHandlerClient {

   public HashMap playerWornHats = new HashMap();
   public HashMap hats = new HashMap();
   public HashMap mobHats = new HashMap();
   public HashMap rendered = new HashMap();
   public HashMap availableHats = new HashMap();
   public HashMap serverHats = new HashMap();
   public ArrayList requestedHats = new ArrayList();
   public ArrayList requestMobHats = new ArrayList();
   public ArrayList requestedMobHats = new ArrayList();
   public World worldInstance;
   public long clock;
   public long lastHitKey;
   public float rotationYaw;
   public float rotationPitch;
   public double posX;
   public double posY;
   public double posZ;
   public boolean isActive;
   public boolean hasScreen;
   public int currentHatRenders;
   public int requestCooldown;
   public GuiHatUnlocked guiHatUnlocked;
   public GuiTradeReq guiNewTradeReq;
   public String tradeReq;
   public int tradeReqTimeout;


   @SubscribeEvent
   public void renderTick(RenderTickEvent event) {
      Minecraft mc = Minecraft.getMinecraft();
      if(mc.theWorld != null) {
         WorldClient world = mc.theWorld;
         if(event.phase == Phase.START) {
            this.currentHatRenders = 0;
            Iterator iterator = this.hats.entrySet().iterator();

            while(iterator.hasNext()) {
               Entry iterator1 = (Entry)iterator.next();
               if(((EntityHat)iterator1.getValue()).parent != null) {
                  EntityHat e = (EntityHat)iterator1.getValue();
                  this.updateHatPosAndAngle(e, e.renderingParent);
               }
            }

            Iterator iterator11 = this.mobHats.entrySet().iterator();

            while(iterator11.hasNext()) {
               Entry e1 = (Entry)iterator11.next();
               if(((EntityHat)e1.getValue()).parent != null) {
                  EntityHat hat = (EntityHat)e1.getValue();
                  this.updateHatPosAndAngle(hat, hat.parent);
               }
            }
         } else {
            if(this.guiHatUnlocked == null) {
               this.guiHatUnlocked = new GuiHatUnlocked(mc);
            }

            this.guiHatUnlocked.updateGui();
            if(this.guiNewTradeReq == null) {
               this.guiNewTradeReq = new GuiTradeReq(mc);
            }

            this.guiNewTradeReq.updateGui();
         }
      }

   }

   @SubscribeEvent
   public void worldTick(ClientTickEvent event) {
      if(event.phase == Phase.END && Minecraft.getMinecraft().theWorld != null) {
         Minecraft mc = Minecraft.getMinecraft();
         WorldClient world = mc.theWorld;
         if(this.worldInstance != world) {
            this.worldInstance = world;
            this.mobHats.clear();
            this.hats.clear();
            this.requestMobHats.clear();
            this.requestedMobHats.clear();
            this.requestCooldown = 40;
         }

         if(Hats.config.getSessionInt("showJoinMessage") == 1) {
            Hats.config.updateSession("showJoinMessage", Integer.valueOf(0));
            mc.thePlayer.addChatMessage(new ChatComponentTranslation(Hats.config.getSessionInt("playerHatsMode") == 4?StatCollector.translateToLocal("hats.firstJoin.hatHunting"):(Hats.config.getSessionInt("playerHatsMode") == 6?StatCollector.translateToLocal("hats.firstJoin.timeActive"):StatCollector.translateToLocal("hats.firstJoin.kingOfTheHat.hasKing")), new Object[0]));
         }

         int ite;
         if(Hats.config.getInt("enableInServersWithoutMod") == 1 && Hats.config.getSessionInt("serverHasMod") == 0 || Hats.config.getSessionInt("serverHasMod") == 1) {
            for(ite = 0; ite < world.playerEntities.size(); ++ite) {
               EntityPlayer ite1 = (EntityPlayer)world.playerEntities.get(ite);
               if((Hats.config.getSessionInt("serverHasMod") != 0 || Hats.config.getInt("shouldOtherPlayersHaveHats") != 0 || ite1 == Minecraft.getMinecraft().thePlayer) && ite1.isEntityAlive()) {
                  EntityHat e = (EntityHat)this.hats.get(ite1.getCommandSenderName());
                  if(e == null || e.isDead) {
                     if(ite1.getCommandSenderName().equalsIgnoreCase(mc.thePlayer.getCommandSenderName())) {
                        Iterator hat = this.hats.entrySet().iterator();

                        Entry hatInfo;
                        while(hat.hasNext()) {
                           hatInfo = (Entry)hat.next();
                           ((EntityHat)hatInfo.getValue()).setDead();
                        }

                        hat = this.mobHats.entrySet().iterator();

                        while(hat.hasNext()) {
                           hatInfo = (Entry)hat.next();
                           ((EntityHat)hatInfo.getValue()).setDead();
                        }

                        this.requestedMobHats.clear();
                     }

                     HatInfo var16 = Hats.config.getSessionInt("serverHasMod") == 1?this.getPlayerHat(ite1.getCommandSenderName()):(Hats.config.getInt("randomHat") != 1 && (Hats.config.getInt("randomHat") != 2 || ite1 == mc.thePlayer)?Hats.favouriteHatInfo:HatHandler.getRandomHatFromList(HatHandler.getAllHats(), false));
                     e = new EntityHat(world, ite1, var16);
                     this.hats.put(ite1.getCommandSenderName(), e);
                     world.spawnEntityInWorld(e);
                  }
               }
            }
         }

         if(this.clock != world.getWorldTime() || !world.getGameRules().getGameRuleBooleanValue("doDaylightCycle")) {
            this.clock = world.getWorldTime();
            if(this.requestCooldown > 0) {
               --this.requestCooldown;
            }

            if(this.tradeReqTimeout > 0) {
               --this.tradeReqTimeout;
               if(this.tradeReqTimeout == 0) {
                  if(mc.currentScreen instanceof GuiHatSelection) {
                     ((GuiHatSelection)mc.currentScreen).updateButtonList();
                  }

                  this.tradeReq = null;
               }
            }

            if(this.clock % 5L == 0L && this.requestCooldown <= 0 && this.requestMobHats.size() > 0) {
               PacketHandler.sendToServer(Hats.channels, new PacketRequestMobHats(this.requestMobHats));
               this.requestMobHats.clear();
            }

            if(Hats.config.getSessionInt("playerHatsMode") == 6) {
               ++this.lastHitKey;
               if(Keyboard.isKeyDown(mc.gameSettings.keyBindForward.getKeyCode()) || Keyboard.isKeyDown(mc.gameSettings.keyBindBack.getKeyCode()) || Keyboard.isKeyDown(mc.gameSettings.keyBindLeft.getKeyCode()) || Keyboard.isKeyDown(mc.gameSettings.keyBindRight.getKeyCode())) {
                  this.lastHitKey = 0L;
               }

               if(this.clock % 107L == 0L) {
                  if((this.lastHitKey <= 100L && (this.lastHitKey != 0L || this.posX != mc.thePlayer.posX || this.posY != mc.thePlayer.posY || this.posZ != mc.thePlayer.posZ) || (this.rotationYaw != mc.thePlayer.rotationYaw || this.rotationPitch != mc.thePlayer.rotationPitch) && (this.posX != mc.thePlayer.posX || this.posY != mc.thePlayer.posY || this.posZ != mc.thePlayer.posZ) && mc.thePlayer.ridingEntity == null) && !this.hasScreen) {
                     if(!this.isActive) {
                        this.isActive = true;
                        PacketHandler.sendToServer(Hats.channels, new PacketPing(1, true));
                     }
                  } else if(this.isActive) {
                     this.isActive = false;
                     PacketHandler.sendToServer(Hats.channels, new PacketPing(1, false));
                  }

                  this.rotationYaw = mc.thePlayer.rotationYaw;
                  this.rotationPitch = mc.thePlayer.rotationPitch;
                  this.posX = mc.thePlayer.posX;
                  this.posY = mc.thePlayer.posY;
                  this.posZ = mc.thePlayer.posZ;
               }
            }
         }

         if(Hats.config.getInt("randomMobHat") > 0 && (Hats.config.getSessionInt("serverHasMod") != 1 || Hats.config.getSessionInt("playerHatsMode") != 4) || Hats.config.getSessionInt("serverHasMod") == 1 && Hats.config.getSessionInt("playerHatsMode") == 4) {
            for(ite = 0; ite < world.loadedEntityList.size(); ++ite) {
               Entity var10 = (Entity)world.loadedEntityList.get(ite);
               if(var10 instanceof EntityLivingBase && (Hats.config.getSessionInt("serverHasMod") == 1 && Hats.config.getSessionInt("playerHatsMode") == 4 || HatHandler.canMobHat((EntityLivingBase)var10)) && !(var10 instanceof EntityPlayer)) {
                  EntityLivingBase var13 = (EntityLivingBase)var10;
                  EntityHat var15 = (EntityHat)this.mobHats.get(Integer.valueOf(var13.getEntityId()));
                  if(var15 == null || var15.isDead) {
                     if(Hats.config.getSessionInt("serverHasMod") != 0 && Hats.config.getSessionInt("playerHatsMode") == 4) {
                        if(!this.requestMobHats.contains(Integer.valueOf(var13.getEntityId())) && !this.requestedMobHats.contains(Integer.valueOf(var13.getEntityId()))) {
                           this.requestMobHats.add(Integer.valueOf(var13.getEntityId()));
                           this.requestedMobHats.add(Integer.valueOf(var13.getEntityId()));
                        }
                     } else {
                        HatInfo var17 = var13.getRNG().nextFloat() < (float)Hats.config.getInt("randomMobHat") / 100.0F?(Hats.config.getInt("randomHat") >= 1?HatHandler.getRandomHatFromList(HatHandler.getAllHats(), false):Hats.favouriteHatInfo):new HatInfo();
                        var15 = new EntityHat(world, var13, var17);
                        this.mobHats.put(Integer.valueOf(var13.getEntityId()), var15);
                        world.spawnEntityInWorld(var15);
                     }
                  }
               }
            }
         }

         Iterator var9 = this.hats.entrySet().iterator();

         while(var9.hasNext()) {
            Entry var12 = (Entry)var9.next();
            if(((EntityHat)var12.getValue()).worldObj.provider.dimensionId != world.provider.dimensionId || world.getWorldTime() - ((EntityHat)var12.getValue()).lastUpdate > 10L) {
               ((EntityHat)var12.getValue()).setDead();
               var9.remove();
            }
         }

         Iterator var11 = this.mobHats.entrySet().iterator();

         while(var11.hasNext()) {
            Entry var14 = (Entry)var11.next();
            if(((EntityHat)var14.getValue()).worldObj.provider.dimensionId != world.provider.dimensionId || world.getWorldTime() - ((EntityHat)var14.getValue()).lastUpdate > 10L) {
               ((EntityHat)var14.getValue()).setDead();
               var11.remove();
            }
         }

         this.hasScreen = mc.currentScreen != null;
      }

   }

   public void updateHatPosAndAngle(EntityHat hat, EntityLivingBase parent) {
      hat.lastTickPosX = hat.parent.lastTickPosX;
      hat.lastTickPosY = hat.parent.lastTickPosY;
      hat.lastTickPosZ = hat.parent.lastTickPosZ;
      hat.prevPosX = hat.parent.prevPosX;
      hat.prevPosY = hat.parent.prevPosY;
      hat.prevPosZ = hat.parent.prevPosZ;
      hat.posX = hat.parent.posX;
      hat.posY = hat.parent.posY;
      hat.posZ = hat.parent.posZ;
      RenderOnEntityHelper helper = HatHandler.getRenderHelper(parent.getClass());
      if(helper != null) {
         hat.prevRotationPitch = helper.getPrevRotationPitch(parent);
         hat.rotationPitch = helper.getRotationPitch(parent);
         hat.prevRotationYaw = helper.getPrevRotationYaw(parent);
         hat.rotationYaw = helper.getRotationYaw(parent);
      }

   }

   public HatInfo getPlayerHat(String s) {
      HatInfo name = (HatInfo)this.playerWornHats.get(s);
      return name == null?(Hats.config.getSessionInt("playerHatsMode") == 2?new HatInfo(Hats.config.getSessionString("lockedHat").toLowerCase()):new HatInfo()):name;
   }
}

package hats.client.core;

import hats.common.core.HatInfo;

public class HatInfoClient extends HatInfo {

   public int recolour;
   public boolean doNotRender;
   public int prevColourR;
   public int prevColourG;
   public int prevColourB;
   public int prevAlpha;


   public HatInfoClient() {}

   public HatInfoClient(String string) {
      super(string);
   }

   public HatInfoClient(String string, int i, int j, int k, int alpha) {
      super(string, i, j, k, alpha);
   }

   public void inherit(HatInfoClient info) {
      this.prevColourR = info.colourR;
      this.prevColourG = info.colourG;
      this.prevColourB = info.colourB;
      this.prevAlpha = info.alpha;
      if(info.hatName.equalsIgnoreCase(super.hatName) && (this.prevColourR != super.colourR || this.prevColourG != super.colourG || this.prevColourB != super.colourB || this.prevAlpha != super.alpha)) {
         this.recolour = 20;
      }

   }

   public void tick() {
      if(this.recolour > 0) {
         --this.recolour;
      }

   }
}

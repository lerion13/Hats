package hats.client.core;

import cpw.mods.fml.client.FMLClientHandler;
import cpw.mods.fml.client.registry.RenderingRegistry;
import cpw.mods.fml.common.FMLCommonHandler;
import hats.client.core.TickHandlerClient;
import hats.client.gui.GuiHatSelection;
import hats.client.render.RenderHat;
import hats.common.core.CommonProxy;
import hats.common.core.HatHandler;
import hats.common.entity.EntityHat;
import hats.common.thread.ThreadHatsReader;
import ichun.common.core.techne.TC2Info;
import ichun.common.core.techne.model.ModelTechne2;
import java.io.File;
import java.util.HashMap;
import net.minecraft.client.Minecraft;

public class ClientProxy extends CommonProxy {

   public static HashMap models = new HashMap();


   public void initRenderersAndTextures() {
      RenderingRegistry.registerEntityRenderingHandler(EntityHat.class, new RenderHat());
   }

   public void initTickHandlers() {
      super.initTickHandlers();
      CommonProxy.tickHandlerClient = new TickHandlerClient();
      FMLCommonHandler.instance().bus().register(CommonProxy.tickHandlerClient);
   }

   public void getHatsAndOpenGui() {
      (new ThreadHatsReader(HatHandler.hatsFolder, false, true)).start();
   }

   public void clearAllHats() {
      super.clearAllHats();
      models.clear();
   }

   public void remap(String duplicate, String original) {
      super.remap(duplicate, original);
      models.put(duplicate, models.get(original));
   }

   public void openHatsGui() {
      FMLClientHandler.instance().displayGuiScreen(Minecraft.getMinecraft().thePlayer, new GuiHatSelection(Minecraft.getMinecraft().thePlayer));
   }

   public void loadHatFile(File file) {
      TC2Info info = TC2Info.readTechneFile(file);
      if(info != null) {
         super.loadHatFile(file);
         String hatName = file.getName().substring(0, file.getName().length() - 4).toLowerCase();
         models.put(hatName, new ModelTechne2(info));
      }

   }

}

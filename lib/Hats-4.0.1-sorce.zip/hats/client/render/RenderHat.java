package hats.client.render;

import hats.api.RenderOnEntityHelper;
import hats.client.gui.GuiHatSelection;
import hats.client.render.HatRendererHelper;
import hats.client.render.helper.HelperGeneric;
import hats.common.Hats;
import hats.common.core.CommonProxy;
import hats.common.core.HatHandler;
import hats.common.entity.EntityHat;
import ichun.common.core.EntityHelperBase;
import ichun.common.core.util.ObfHelper;
import java.nio.FloatBuffer;
import morph.api.Api;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.inventory.GuiContainerCreative;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.renderer.GLAllocation;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class RenderHat extends Render {

   public RenderHat() {
      super.shadowSize = 0.0F;
   }

   public void renderHat(EntityHat hat, double par2, double par4, double par6, float par8, float par9) {
      if(hat.info != null && !hat.info.hatName.equalsIgnoreCase("") && !hat.renderingParent.isPlayerSleeping() && hat.renderingParent.isEntityAlive() && !hat.renderingParent.isChild() && (Hats.config.getSessionInt("renderHats") == 1 || Hats.config.getSessionInt("renderHats") == 13131) && hat.render) {
         boolean firstPerson = hat.parent == Minecraft.getMinecraft().renderViewEntity && Minecraft.getMinecraft().gameSettings.thirdPersonView == 0 && (!(Minecraft.getMinecraft().currentScreen instanceof GuiInventory) && !(Minecraft.getMinecraft().currentScreen instanceof GuiContainerCreative) && !(Minecraft.getMinecraft().currentScreen instanceof GuiHatSelection) || RenderManager.instance.playerViewY != 180.0F);
         if((Hats.config.getInt("renderInFirstPerson") == 1 && firstPerson || !firstPerson) && !hat.renderingParent.isInvisible()) {
            boolean isPlayer = hat.parent instanceof EntityPlayer;
            if(!isPlayer) {
               CommonProxy var10000 = Hats.proxy;
               if(CommonProxy.tickHandlerClient.mobHats.get(Integer.valueOf(hat.parent.getEntityId())) != hat) {
                  hat.setDead();
                  return;
               }
            }

            boolean noHelper = false;
            RenderOnEntityHelper helper = HatHandler.getRenderHelper(hat.renderingParent.getClass());
            if(helper instanceof HelperGeneric) {
               ((HelperGeneric)helper).update(hat.renderingParent);
            }

            float alpha = 1.0F;
            if(helper == null) {
               noHelper = true;
               if(!(hat.parent instanceof EntityPlayer)) {
                  return;
               }

               helper = HatHandler.getRenderHelper(EntityPlayer.class);
               alpha = 0.0F;
            }

            float renderTick = par9;
            helper.renderTick = par9;
            FloatBuffer buffer = GLAllocation.createDirectFloatBuffer(16);
            FloatBuffer buffer1 = GLAllocation.createDirectFloatBuffer(16);
            GL11.glPushMatrix();
            GL11.glGetFloat(2982, buffer);
            Render rend = RenderManager.instance.getEntityRenderObject(hat.renderingParent);
            ObfHelper.invokePreRenderCallback(rend, rend.getClass(), hat.renderingParent, par9);
            GL11.glGetFloat(2982, buffer1);
            GL11.glPopMatrix();
            float prevScaleX = buffer1.get(0) / buffer.get(0);
            float prevScaleY = buffer1.get(5) / buffer.get(5);
            float prevScaleZ = buffer1.get(8) / buffer.get(8);
            int passesNeeded = helper.passesNeeded();
            float hatScale;
            float posSide;
            float posHori;
            float offVert;
            if(Hats.hasMorphMod && hat.parent instanceof EntityPlayer && Hats.config.getSessionInt("renderHats") != 13131) {
               EntityPlayer i = (EntityPlayer)hat.parent;
               if(Api.hasMorph(i.getCommandSenderName(), true) && Api.morphProgress(i.getCommandSenderName(), true) < 1.0F) {
                  hatScale = MathHelper.clamp_float(((Api.morphProgress(i.getCommandSenderName(), true) * 80.0F + par9) / 80.0F - 0.125F) / 0.75F, 0.0F, 1.0F);
                  EntityLivingBase renderYaw = Api.getPrevMorphEntity(i.getCommandSenderName(), true);
                  if(renderYaw != null) {
                     RenderOnEntityHelper rotationYaw = HatHandler.getRenderHelper(renderYaw.getClass());
                     if(rotationYaw != null) {
                        FloatBuffer rotationPitch = GLAllocation.createDirectFloatBuffer(16);
                        FloatBuffer rotationRoll = GLAllocation.createDirectFloatBuffer(16);
                        GL11.glPushMatrix();
                        GL11.glGetFloat(2982, rotationPitch);
                        Render posVert = RenderManager.instance.getEntityRenderObject(renderYaw);
                        ObfHelper.invokePreRenderCallback(posVert, posVert.getClass(), renderYaw, par9);
                        GL11.glGetFloat(2982, rotationRoll);
                        GL11.glPopMatrix();
                        posHori = rotationRoll.get(0) / rotationPitch.get(0);
                        posSide = rotationRoll.get(5) / rotationPitch.get(5);
                        offVert = rotationRoll.get(8) / rotationPitch.get(8);
                        prevScaleX = posHori + (prevScaleX - posHori) * hatScale;
                        prevScaleY = posSide + (prevScaleY - posSide) * hatScale;
                        prevScaleZ = offVert + (prevScaleZ - offVert) * hatScale;
                        if(passesNeeded < rotationYaw.passesNeeded()) {
                           passesNeeded = rotationYaw.passesNeeded();
                        }

                        if(alpha == 0.0F) {
                           alpha = 1.0F - hatScale;
                        }
                     } else if(noHelper) {
                        alpha = 0.0F;
                     } else {
                        alpha = alpha == 0.0F?1.0F - hatScale:hatScale;
                     }
                  } else {
                     alpha = alpha == 0.0F?1.0F - hatScale:hatScale;
                  }
               }
            }

            if(alpha == 0.0F) {
               return;
            }

            GL11.glPushMatrix();
            if(isPlayer && hat.parent == Minecraft.getMinecraft().renderViewEntity && hat.parent.isSneaking()) {
               GL11.glTranslatef(0.0F, -0.075F, 0.0F);
            }

            GL11.glTranslated(par2, par4, par6);
            GL11.glTranslatef(0.0F, -hat.parent.yOffset, 0.0F);
            int var55;
            if(Hats.config.getSessionInt("renderHats") == 1) {
               GL11.glTranslatef(0.0F, (float)(-(hat.lastTickPosY - hat.parent.lastTickPosY)) + (float)(hat.parent.boundingBox.minY + (double)hat.parent.yOffset - hat.parent.posY), 0.0F);
               var55 = hat.renderingParent.getBrightnessForRender(par9);
               int var58 = var55 % 65536;
               int var56 = var55 / 65536;
               OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, (float)var58 / 1.0F, (float)var56 / 1.0F);
            }

            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);

            for(var55 = 0; var55 < passesNeeded; ++var55) {
               if(var55 < helper.passesNeeded()) {
                  helper.currentPass = var55;
               } else {
                  helper.currentPass = 0;
               }

               hatScale = helper.getHatScale(hat.renderingParent);
               float var57 = EntityHelperBase.interpolateRotation(helper.getPrevRenderYaw(hat.renderingParent), helper.getRenderYaw(hat.renderingParent), renderTick);
               float var60 = EntityHelperBase.interpolateRotation(helper.getPrevRotationYaw(hat.renderingParent), helper.getRotationYaw(hat.renderingParent), renderTick);
               float var61 = EntityHelperBase.interpolateRotation(helper.getPrevRotationPitch(hat.renderingParent), helper.getRotationPitch(hat.renderingParent), renderTick);
               float var59 = EntityHelperBase.interpolateRotation(helper.getPrevRotationRoll(hat.renderingParent), helper.getRotationRoll(hat.renderingParent), renderTick);
               float var62 = helper.getRotatePointVert(hat.renderingParent);
               posHori = helper.getRotatePointHori(hat.renderingParent);
               posSide = helper.getRotatePointSide(hat.renderingParent);
               offVert = helper.getOffsetPointVert(hat.renderingParent);
               float offHori = helper.getOffsetPointHori(hat.renderingParent);
               float offSide = helper.getOffsetPointSide(hat.renderingParent);
               boolean renderHatSkin = true;
               boolean renderSkin = false;
               ResourceLocation skinLoc = AbstractClientPlayer.locationStevePng;
               float skinAlpha = alpha;
               if(Hats.hasMorphMod && hat.parent instanceof EntityPlayer && Hats.config.getSessionInt("renderHats") != 13131) {
                  EntityPlayer player = (EntityPlayer)hat.parent;
                  if(Api.hasMorph(player.getCommandSenderName(), true) && Api.morphProgress(player.getCommandSenderName(), true) < 1.0F) {
                     float realProg = Api.morphProgress(player.getCommandSenderName(), true);
                     float prog = MathHelper.clamp_float(((realProg * 80.0F + renderTick) / 80.0F - 0.125F) / 0.75F, 0.0F, 1.0F);
                     EntityLivingBase prevMorph = Api.getPrevMorphEntity(player.getCommandSenderName(), true);
                     if(prevMorph != null) {
                        RenderOnEntityHelper helper1 = HatHandler.getRenderHelper(prevMorph.getClass());
                        if(helper1 != null) {
                           if(var55 < helper1.passesNeeded()) {
                              helper1.currentPass = var55;
                           } else {
                              helper1.currentPass = 0;
                           }

                           float ahatScale = helper1.getHatScale(prevMorph);
                           float arenderYaw = EntityHelperBase.interpolateRotation(helper1.getPrevRenderYaw(prevMorph), helper1.getRenderYaw(prevMorph), renderTick);
                           float arotationYaw = EntityHelperBase.interpolateRotation(helper1.getPrevRotationYaw(prevMorph), helper1.getRotationYaw(prevMorph), renderTick);
                           float arotationPitch = EntityHelperBase.interpolateRotation(helper1.getPrevRotationPitch(prevMorph), helper1.getRotationPitch(prevMorph), renderTick);
                           float arotationRoll = helper1.getRotationRoll(prevMorph);
                           float aposVert = helper1.getRotatePointVert(prevMorph);
                           float aposHori = helper1.getRotatePointHori(prevMorph);
                           float aposSide = helper1.getRotatePointSide(prevMorph);
                           float aoffVert = helper1.getOffsetPointVert(prevMorph);
                           float aoffHori = helper1.getOffsetPointHori(prevMorph);
                           float aoffSide = helper1.getOffsetPointSide(prevMorph);
                           hatScale = ahatScale + (hatScale - ahatScale) * prog;
                           var57 = arenderYaw + (var57 - arenderYaw) * prog;
                           var60 = arotationYaw + (var60 - arotationYaw) * prog;
                           var61 = arotationPitch + (var61 - arotationPitch) * prog;
                           var59 = arotationRoll + (var59 - arotationRoll) * prog;
                           var62 = aposVert + (var62 - aposVert) * prog;
                           posHori = aposHori + (posHori - aposHori) * prog;
                           posSide = aposSide + (posSide - aposSide) * prog;
                           offVert = aoffVert + (offVert - aoffVert) * prog;
                           offHori = aoffHori + (offHori - aoffHori) * prog;
                           offSide = aoffSide + (offSide - aoffSide) * prog;
                           renderSkin = true;
                           skinLoc = Api.getMorphSkinTexture();
                           if(alpha == 1.0F) {
                              if(realProg <= 0.125F) {
                                 skinAlpha = MathHelper.clamp_float((realProg * 80.0F + renderTick) / 80.0F / 0.125F, 0.0F, 1.0F);
                              } else if(realProg > 0.875F) {
                                 skinAlpha = MathHelper.clamp_float(1.0F - ((realProg * 80.0F + renderTick) / 80.0F - 0.875F) / 0.125F, 0.0F, 1.0F);
                              } else {
                                 renderHatSkin = false;
                              }
                           }
                        }
                     }
                  }
               }

               if(renderHatSkin) {
                  HatRendererHelper.renderHat(hat.info, alpha, hatScale, prevScaleX, prevScaleY, prevScaleZ, var57, var60, var61, var59, var62, posHori, posSide, offVert, offHori, offSide, isPlayer, true, renderTick);
               }

               if(renderSkin) {
                  Minecraft.getMinecraft().getTextureManager().bindTexture(skinLoc);
                  HatRendererHelper.renderHat(hat.info, skinAlpha, hatScale, prevScaleX, prevScaleY, prevScaleZ, var57, var60, var61, var59, var62, posHori, posSide, offVert, offHori, offSide, isPlayer, false, renderTick);
               }
            }

            GL11.glPopMatrix();
         }
      }

   }

   public void doRender(Entity par1Entity, double par2, double par4, double par6, float par8, float par9) {
      this.renderHat((EntityHat)par1Entity, par2, par4, par6, par8, par9);
   }

   protected ResourceLocation getEntityTexture(Entity entity) {
      return AbstractClientPlayer.locationStevePng;
   }
}

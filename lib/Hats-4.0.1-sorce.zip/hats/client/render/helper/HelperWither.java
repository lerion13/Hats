package hats.client.render.helper;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import hats.api.RenderOnEntityHelper;
import hats.common.Hats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.EntityWither;

public class HelperWither extends RenderOnEntityHelper {

   public Class helperForClass() {
      return EntityWither.class;
   }

   public boolean canWearHat(EntityLivingBase living) {
      return Hats.config.getInt("hatWither") == 1;
   }

   @SideOnly(Side.CLIENT)
   public float getPrevRotationYaw(EntityLivingBase living) {
      return super.currentPass == 0?living.prevRotationYawHead:((EntityWither)living).func_82207_a(super.currentPass - 1);
   }

   @SideOnly(Side.CLIENT)
   public float getRotationYaw(EntityLivingBase living) {
      return super.currentPass == 0?living.rotationYawHead:((EntityWither)living).func_82207_a(super.currentPass - 1);
   }

   @SideOnly(Side.CLIENT)
   public float getPrevRotationPitch(EntityLivingBase living) {
      return super.currentPass == 0?living.prevRotationPitch:((EntityWither)living).func_82210_r(super.currentPass - 1);
   }

   @SideOnly(Side.CLIENT)
   public float getRotationPitch(EntityLivingBase living) {
      return super.currentPass == 0?living.rotationPitch:((EntityWither)living).func_82210_r(super.currentPass - 1);
   }

   public float getRotatePointVert(EntityLivingBase ent) {
      return super.currentPass == 0?1.508125F:1.258125F;
   }

   public float getRotatePointHori(EntityLivingBase ent) {
      return 0.0F;
   }

   public float getRotatePointSide(EntityLivingBase ent) {
      return super.currentPass == 0?0.0F:(super.currentPass == 1?0.5F:-0.625F);
   }

   public float getOffsetPointVert(EntityLivingBase ent) {
      return 0.25F;
   }

   public float getOffsetPointHori(EntityLivingBase ent) {
      return super.currentPass == 0?0.0F:0.0625F;
   }

   public float getOffsetPointSide(EntityLivingBase ent) {
      return super.currentPass == 0?0.0F:(super.currentPass == 1?0.0625F:0.0625F);
   }

   public float getHatScale(EntityLivingBase ent) {
      return super.currentPass == 0?1.0F:0.75F;
   }

   public int passesNeeded() {
      return 3;
   }
}

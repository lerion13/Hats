package hats.client.render.helper;

import hats.api.RenderOnEntityHelper;
import hats.common.Hats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntitySheep;

public class HelperSheep extends RenderOnEntityHelper {

   public Class helperForClass() {
      return EntitySheep.class;
   }

   public boolean canWearHat(EntityLivingBase living) {
      return Hats.config.getInt("hatSheep") == 1;
   }

   public float getRotatePointVert(EntityLivingBase ent) {
      return 1.1375F;
   }

   public float getRotatePointHori(EntityLivingBase ent) {
      return 0.5F;
   }

   public float getOffsetPointVert(EntityLivingBase ent) {
      return 0.25F;
   }

   public float getOffsetPointHori(EntityLivingBase ent) {
      return 0.1875F;
   }

   public float getHatScale(EntityLivingBase ent) {
      return ((EntitySheep)ent).func_70894_j(1.0F) != 0.0F?0.0F:0.75F;
   }
}

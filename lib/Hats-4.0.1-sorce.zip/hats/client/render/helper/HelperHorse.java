package hats.client.render.helper;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import hats.api.RenderOnEntityHelper;
import hats.common.Hats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityHorse;

public class HelperHorse extends RenderOnEntityHelper {

   public Class helperForClass() {
      return EntityHorse.class;
   }

   public boolean canWearHat(EntityLivingBase living) {
      return Hats.config.getInt("hatHorse") == 1;
   }

   public float getPrevRotationYaw(EntityLivingBase living) {
      return living.prevRenderYawOffset + 180.0F;
   }

   public float getRotationYaw(EntityLivingBase living) {
      return living.renderYawOffset + 180.0F;
   }

   @SideOnly(Side.CLIENT)
   public float getPrevRotationPitch(EntityLivingBase living) {
      return (float)Math.toDegrees((double)(((EntityHorse)living).getRearingAmount(1.0F) * 0.7853982F));
   }

   @SideOnly(Side.CLIENT)
   public float getRotationPitch(EntityLivingBase living) {
      return (float)Math.toDegrees((double)(((EntityHorse)living).getRearingAmount(1.0F) * 0.7853982F));
   }

   public float getRotatePointVert(EntityLivingBase ent) {
      return 0.8125F;
   }

   public float getRotatePointHori(EntityLivingBase ent) {
      return -0.5625F;
   }

   public float getOffsetPointVert(EntityLivingBase ent) {
      return 0.5F;
   }

   public float getOffsetPointHori(EntityLivingBase ent) {
      return 0.0F;
   }

   public float getHatScale(EntityLivingBase ent) {
      return 1.25F;
   }
}

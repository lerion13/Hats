package hats.client.render.helper;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import hats.api.RenderOnEntityHelper;
import hats.common.Hats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityWolf;

public class HelperWolf extends RenderOnEntityHelper {

   public Class helperForClass() {
      return EntityWolf.class;
   }

   public boolean canWearHat(EntityLivingBase living) {
      return Hats.config.getInt("hatWolf") == 1;
   }

   @SideOnly(Side.CLIENT)
   public float getPrevRotationRoll(EntityLivingBase living) {
      return (float)Math.toDegrees((double)(((EntityWolf)living).getInterestedAngle(1.0F) + ((EntityWolf)living).getShakeAngle(1.0F, 0.0F)));
   }

   @SideOnly(Side.CLIENT)
   public float getRotationRoll(EntityLivingBase living) {
      return (float)Math.toDegrees((double)(((EntityWolf)living).getInterestedAngle(1.0F) + ((EntityWolf)living).getShakeAngle(1.0F, 0.0F)));
   }

   public float getRotatePointVert(EntityLivingBase ent) {
      return 0.6653125F;
   }

   public float getRotatePointHori(EntityLivingBase ent) {
      return 0.4375F;
   }

   public float getRotatePointSide(EntityLivingBase ent) {
      return 0.0625F;
   }

   public float getOffsetPointVert(EntityLivingBase ent) {
      return 0.1875F;
   }

   public float getOffsetPointHori(EntityLivingBase ent) {
      return -0.0625F;
   }

   public float getHatScale(EntityLivingBase ent) {
      return 0.75F;
   }
}

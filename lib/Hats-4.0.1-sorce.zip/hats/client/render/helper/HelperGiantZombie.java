package hats.client.render.helper;

import hats.api.RenderOnEntityHelper;
import hats.common.Hats;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityGiantZombie;

public class HelperGiantZombie extends RenderOnEntityHelper {

   public Class helperForClass() {
      return EntityGiantZombie.class;
   }

   public boolean canWearHat(EntityLivingBase living) {
      return Hats.config.getInt("hatZombie") == 1;
   }

   public float getRotatePointVert(EntityLivingBase ent) {
      return ent.isSneaking()?(ent == Minecraft.getMinecraft().thePlayer?1.4375F:1.3125F):1.5F;
   }

   public float getOffsetPointVert(EntityLivingBase ent) {
      return 0.5F;
   }
}

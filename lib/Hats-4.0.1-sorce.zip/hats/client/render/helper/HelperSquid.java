package hats.client.render.helper;

import hats.api.RenderOnEntityHelper;
import hats.common.Hats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntitySquid;

public class HelperSquid extends RenderOnEntityHelper {

   public Class helperForClass() {
      return EntitySquid.class;
   }

   public boolean canWearHat(EntityLivingBase living) {
      return Hats.config.getInt("hatSquid") == 1;
   }

   public float getPrevRotationYaw(EntityLivingBase living) {
      return living.prevRenderYawOffset;
   }

   public float getRotationYaw(EntityLivingBase living) {
      return living.renderYawOffset;
   }

   public float getPrevRotationPitch(EntityLivingBase living) {
      return -((EntitySquid)living).prevSquidPitch;
   }

   public float getRotationPitch(EntityLivingBase living) {
      return -((EntitySquid)living).squidPitch;
   }

   public float getRotatePointVert(EntityLivingBase ent) {
      return 0.5F;
   }

   public float getOffsetPointVert(EntityLivingBase ent) {
      return 0.3125F;
   }

   public float getHatScale(EntityLivingBase ent) {
      return 1.5F;
   }
}

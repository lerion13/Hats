package hats.client.render.helper;

import hats.api.RenderOnEntityHelper;
import hats.common.Hats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityCreeper;

public class HelperCreeper extends RenderOnEntityHelper {

   public Class helperForClass() {
      return EntityCreeper.class;
   }

   public boolean canWearHat(EntityLivingBase living) {
      return Hats.config.getInt("hatCreeper") == 1;
   }

   public float getRotatePointVert(EntityLivingBase ent) {
      return 1.259375F;
   }

   public float getOffsetPointVert(EntityLivingBase ent) {
      return 0.5F;
   }
}

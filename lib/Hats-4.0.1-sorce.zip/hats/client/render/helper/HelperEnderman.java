package hats.client.render.helper;

import hats.api.RenderOnEntityHelper;
import hats.common.Hats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityEnderman;

public class HelperEnderman extends RenderOnEntityHelper {

   public Class helperForClass() {
      return EntityEnderman.class;
   }

   public boolean canWearHat(EntityLivingBase living) {
      return Hats.config.getInt("hatEnderman") == 1;
   }

   public float getRotatePointVert(EntityLivingBase ent) {
      return 2.31875F;
   }

   public float getOffsetPointVert(EntityLivingBase ent) {
      return ((EntityEnderman)ent).isScreaming()?0.8125F:0.5F;
   }
}

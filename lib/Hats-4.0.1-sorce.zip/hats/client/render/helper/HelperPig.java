package hats.client.render.helper;

import hats.api.RenderOnEntityHelper;
import hats.common.Hats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityPig;

public class HelperPig extends RenderOnEntityHelper {

   public Class helperForClass() {
      return EntityPig.class;
   }

   public boolean canWearHat(EntityLivingBase living) {
      return Hats.config.getInt("hatPig") == 1;
   }

   public float getRotatePointVert(EntityLivingBase ent) {
      return 0.771875F;
   }

   public float getRotatePointHori(EntityLivingBase ent) {
      return 0.375F;
   }

   public float getOffsetPointVert(EntityLivingBase ent) {
      return 0.23125F;
   }

   public float getOffsetPointHori(EntityLivingBase ent) {
      return 0.25F;
   }
}

package hats.client.render.helper;

import hats.api.RenderOnEntityHelper;
import net.minecraft.entity.EntityLivingBase;

public class HelperGeneric extends RenderOnEntityHelper {

   public final Class entityClass;
   public final boolean canUnlockHat;
   public float entPrevRenderYawOffset;
   public float entRenderYawOffset;
   public float entPrevRotationYawHead;
   public float entRotationYawHead;
   public float entPrevRotationPitch;
   public float entRotationPitch;
   public Object prevRenderYawOffset;
   public Object renderYawOffset;
   public Object prevRotationYawHead;
   public Object rotationYawHead;
   public Object prevRotationPitch;
   public Object rotationPitch;
   public Object rotatePointVert;
   public Object rotatePointHori;
   public Object rotatePointSide;
   public Object offsetPointVert;
   public Object offsetPointHori;
   public Object offsetPointSide;
   public Object hatScale;


   public HelperGeneric(Class entityClass, boolean canUnlockHat) {
      this.entityClass = entityClass;
      this.canUnlockHat = canUnlockHat;
   }

   public Class helperForClass() {
      return this.entityClass;
   }

   public boolean canUnlockHat(EntityLivingBase living) {
      return this.canUnlockHat;
   }

   public void update(EntityLivingBase living) {
      this.entPrevRenderYawOffset = living.prevRenderYawOffset;
      this.entRenderYawOffset = living.renderYawOffset;
      this.entPrevRotationYawHead = living.prevRotationYawHead;
      this.entRotationYawHead = living.rotationYawHead;
      this.entPrevRotationPitch = living.prevRotationPitch;
      this.entRotationPitch = living.rotationPitch;
   }

   public float getPrevRenderYaw(EntityLivingBase living) {
      return this.getValue("prevRenderYawOffset");
   }

   public float getRenderYaw(EntityLivingBase living) {
      return this.getValue("renderYawOffset");
   }

   public float getPrevRotationYaw(EntityLivingBase living) {
      return this.getValue("prevRotationYawHead");
   }

   public float getRotationYaw(EntityLivingBase living) {
      return this.getValue("rotationYawHead");
   }

   public float getPrevRotationPitch(EntityLivingBase living) {
      return this.getValue("prevRotationPitch");
   }

   public float getRotationPitch(EntityLivingBase living) {
      return this.getValue("rotationPitch");
   }

   public float getRotatePointVert(EntityLivingBase ent) {
      return this.getValue("rotatePointVert");
   }

   public float getRotatePointHori(EntityLivingBase ent) {
      return this.getValue("rotatePointHori");
   }

   public float getRotatePointSide(EntityLivingBase ent) {
      return this.getValue("rotatePointSide");
   }

   public float getOffsetPointVert(EntityLivingBase ent) {
      return this.getValue("offsetPointVert");
   }

   public float getOffsetPointHori(EntityLivingBase ent) {
      return this.getValue("offsetPointHori");
   }

   public float getOffsetPointSide(EntityLivingBase ent) {
      return this.getValue("offsetPointSide");
   }

   public float getHatScale(EntityLivingBase ent) {
      return this.getValue("hatScale");
   }

   public float getValue(String s) {
      Object obj = null;
      if(s.equalsIgnoreCase("prevRenderYawOffset")) {
         obj = this.prevRenderYawOffset;
      } else if(s.equalsIgnoreCase("renderYawOffset")) {
         obj = this.renderYawOffset;
      } else if(s.equalsIgnoreCase("prevRotationYawHead")) {
         obj = this.prevRotationYawHead;
      } else if(s.equalsIgnoreCase("rotationYawHead")) {
         obj = this.rotationYawHead;
      } else if(s.equalsIgnoreCase("prevRotationPitch")) {
         obj = this.prevRotationPitch;
      } else if(s.equalsIgnoreCase("rotationPitch")) {
         obj = this.rotationPitch;
      } else if(s.equalsIgnoreCase("rotatePointVert")) {
         obj = this.rotatePointVert;
      } else if(s.equalsIgnoreCase("rotatePointHori")) {
         obj = this.rotatePointHori;
      } else if(s.equalsIgnoreCase("rotatePointSide")) {
         obj = this.rotatePointSide;
      } else if(s.equalsIgnoreCase("offsetPointVert")) {
         obj = this.offsetPointVert;
      } else if(s.equalsIgnoreCase("offsetPointHori")) {
         obj = this.offsetPointHori;
      } else if(s.equalsIgnoreCase("offsetPointSide")) {
         obj = this.offsetPointSide;
      } else if(s.equalsIgnoreCase("hatScale")) {
         obj = this.hatScale;
      }

      if(obj != null || !s.equalsIgnoreCase("hatScale")) {
         if(obj instanceof Float) {
            return ((Float)obj).floatValue();
         }

         if(obj instanceof String || obj == null) {
            return this.getEntValue(obj == null?s:(String)obj);
         }
      }

      return s.equals("hatScale")?1.0F:0.0F;
   }

   public float getEntValue(String s) {
      return s.equalsIgnoreCase("prevRenderYawOffset")?this.entPrevRenderYawOffset:(s.equalsIgnoreCase("renderYawOffset")?this.entRenderYawOffset:(s.equalsIgnoreCase("prevRotationYawHead")?this.entPrevRotationYawHead:(s.equalsIgnoreCase("rotationYawHead")?this.entRotationYawHead:(s.equalsIgnoreCase("prevRotationPitch")?this.entPrevRotationPitch:(s.equalsIgnoreCase("rotationPitch")?this.entRotationPitch:0.0F)))));
   }
}

package hats.client.render.helper;

import hats.api.RenderOnEntityHelper;
import hats.common.Hats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityOcelot;

public class HelperOcelot extends RenderOnEntityHelper {

   public Class helperForClass() {
      return EntityOcelot.class;
   }

   public boolean canWearHat(EntityLivingBase living) {
      return Hats.config.getInt("hatOcelot") == 1;
   }

   public float getRotatePointVert(EntityLivingBase ent) {
      return ((EntityOcelot)ent).isSitting()?0.775F:(ent.isSneaking()?0.4375F:0.56875F);
   }

   public float getRotatePointHori(EntityLivingBase ent) {
      return ((EntityOcelot)ent).isSitting()?0.5F:0.5625F;
   }

   public float getOffsetPointVert(EntityLivingBase ent) {
      return 0.125F;
   }

   public float getHatScale(EntityLivingBase ent) {
      return 0.75F;
   }
}

package hats.client.render.helper;

import hats.api.RenderOnEntityHelper;
import hats.common.Hats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityChicken;

public class HelperChicken extends RenderOnEntityHelper {

   public Class helperForClass() {
      return EntityChicken.class;
   }

   public boolean canWearHat(EntityLivingBase living) {
      return Hats.config.getInt("hatChicken") == 1;
   }

   public float getRotatePointVert(EntityLivingBase ent) {
      return 0.5625F;
   }

   public float getRotatePointHori(EntityLivingBase ent) {
      return 0.25F;
   }

   public float getOffsetPointVert(EntityLivingBase ent) {
      return 0.384375F;
   }

   public float getHatScale(EntityLivingBase ent) {
      return 0.5F;
   }
}

package hats.client.render.helper;

import hats.api.RenderOnEntityHelper;
import hats.common.Hats;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityZombie;

public class HelperZombie extends RenderOnEntityHelper {

   public Class helperForClass() {
      return EntityZombie.class;
   }

   public boolean canWearHat(EntityLivingBase living) {
      return Hats.config.getInt("hatZombie") == 1;
   }

   public float getRotatePointVert(EntityLivingBase ent) {
      return ent.isSneaking()?(ent == Minecraft.getMinecraft().thePlayer?1.4375F:1.3125F):1.509375F;
   }

   public float getOffsetPointVert(EntityLivingBase ent) {
      return ((EntityZombie)ent).isVillager()?0.625F:0.5F;
   }
}

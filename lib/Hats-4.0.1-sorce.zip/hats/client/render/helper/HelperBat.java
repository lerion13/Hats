package hats.client.render.helper;

import hats.api.RenderOnEntityHelper;
import hats.common.Hats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityBat;
import net.minecraft.util.MathHelper;

public class HelperBat extends RenderOnEntityHelper {

   public Class helperForClass() {
      return EntityBat.class;
   }

   public boolean canWearHat(EntityLivingBase living) {
      return Hats.config.getInt("hatBat") == 1;
   }

   public float getRotatePointHori(EntityLivingBase ent) {
      return 0.0F;
   }

   public float getOffsetPointHori(EntityLivingBase ent) {
      return 0.0F;
   }

   public float getRotatePointVert(EntityLivingBase ent) {
      return 1.5F + MathHelper.cos(((float)ent.ticksExisted + super.renderTick) * 0.3F) * 0.275F;
   }

   public float getOffsetPointVert(EntityLivingBase ent) {
      return 0.1875F;
   }

   public float getHatScale(EntityLivingBase ent) {
      return ((EntityBat)ent).getIsBatHanging()?0.0F:0.8F;
   }
}

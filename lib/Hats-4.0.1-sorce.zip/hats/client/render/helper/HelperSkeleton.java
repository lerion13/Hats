package hats.client.render.helper;

import hats.api.RenderOnEntityHelper;
import hats.common.Hats;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntitySkeleton;

public class HelperSkeleton extends RenderOnEntityHelper {

   public Class helperForClass() {
      return EntitySkeleton.class;
   }

   public boolean canWearHat(EntityLivingBase living) {
      return Hats.config.getInt("hatSkeleton") == 1;
   }

   public float getRotatePointVert(EntityLivingBase ent) {
      return ent.isSneaking()?(ent == Minecraft.getMinecraft().thePlayer?1.4375F:1.3125F):1.5F;
   }

   public float getOffsetPointVert(EntityLivingBase ent) {
      return 0.5F;
   }
}

package hats.client.gui;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import hats.client.core.HatInfoClient;
import hats.client.render.HatRendererHelper;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.StatCollector;
import org.lwjgl.opengl.GL11;

@SideOnly(Side.CLIENT)
public class GuiHatUnlocked extends Gui {

   private static final ResourceLocation texAchi = new ResourceLocation("textures/gui/achievement/achievement_background.png");
   private Minecraft theGame;
   private int width;
   private int height;
   private String headerText;
   private String hatNameText;
   private long unlockedTime;
   public ArrayList hatList = new ArrayList();
   private HatInfoClient info = null;


   public GuiHatUnlocked(Minecraft par1Minecraft) {
      this.theGame = par1Minecraft;
      this.headerText = "§e" + StatCollector.translateToLocal("hats.hatUnlocked");
      this.hatNameText = "";
   }

   public void queueHatUnlocked(String hat) {
      if(!this.hatNameText.equalsIgnoreCase(hat)) {
         if(!this.hatList.contains(hat)) {
            this.hatList.add(hat);
         }

         this.showNextHatUnlocked();
      }

   }

   public void showNextHatUnlocked() {
      if(this.hatList.size() > 0 && this.unlockedTime == 0L) {
         this.hatNameText = (String)this.hatList.get(0);
         this.unlockedTime = Minecraft.getSystemTime();
         this.hatList.remove(0);
         this.info = new HatInfoClient(this.hatNameText.toLowerCase(), 255, 255, 255, 255);
      }

   }

   private void updateWindowScale() {
      GL11.glViewport(0, 0, this.theGame.displayWidth, this.theGame.displayHeight);
      GL11.glMatrixMode(5889);
      GL11.glLoadIdentity();
      GL11.glMatrixMode(5888);
      GL11.glLoadIdentity();
      this.width = this.theGame.displayWidth;
      this.height = this.theGame.displayHeight;
      ScaledResolution scaledresolution = new ScaledResolution(this.theGame, this.theGame.displayWidth, this.theGame.displayHeight);
      this.width = scaledresolution.getScaledWidth();
      this.height = scaledresolution.getScaledHeight();
      GL11.glClear(256);
      GL11.glMatrixMode(5889);
      GL11.glLoadIdentity();
      GL11.glOrtho(0.0D, (double)this.width, (double)this.height, 0.0D, 1000.0D, 3000.0D);
      GL11.glMatrixMode(5888);
      GL11.glLoadIdentity();
      GL11.glTranslatef(0.0F, 0.0F, -2000.0F);
   }

   public void updateGui() {
      GL11.glPushMatrix();
      if(this.unlockedTime != 0L) {
         double d0 = (double)(Minecraft.getSystemTime() - this.unlockedTime) / 3000.0D;
         if(d0 >= 0.0D && d0 <= 1.0D && !this.hatNameText.equalsIgnoreCase("")) {
            this.updateWindowScale();
            GL11.glDisable(2929);
            GL11.glDepthMask(false);
            double d1 = d0 * 2.0D;
            if(d1 > 1.0D) {
               d1 = 2.0D - d1;
            }

            d1 *= 4.0D;
            d1 = 1.0D - d1;
            if(d1 < 0.0D) {
               d1 = 0.0D;
            }

            d1 *= d1;
            d1 *= d1;
            int i = this.width - 160;
            int j = 0 - (int)(d1 * 36.0D);
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
            GL11.glEnable(3553);
            this.theGame.getTextureManager().bindTexture(texAchi);
            GL11.glDisable(2896);
            this.drawTexturedModalRect(i, j, 96, 202, 160, 32);
            this.theGame.fontRenderer.drawString(this.headerText, i + 30, j + 7, -256);
            this.theGame.fontRenderer.drawString(this.hatNameText, i + 30, j + 18, -1);
            RenderHelper.enableGUIStandardItemLighting();
            GL11.glDisable(2896);
            GL11.glEnable('\u803a');
            GL11.glEnable(2903);
            GL11.glEnable(2896);
            GL11.glTranslatef((float)i + 16.0F, (float)j + 16.0F, 50.0F);
            GL11.glEnable(2929);
            GL11.glDepthMask(true);
            GL11.glScalef(1.0F, -1.0F, 1.0F);
            GL11.glScalef(20.0F, 20.0F, 20.0F);
            GL11.glRotatef(10.0F, 1.0F, 0.0F, 0.0F);
            GL11.glRotatef(-22.5F, 0.0F, 1.0F, 0.0F);
            GL11.glRotatef((float)(Minecraft.getSystemTime() - this.unlockedTime) / 6.0F, 0.0F, 1.0F, 0.0F);
            HatRendererHelper.renderHat(this.info, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, true, true, 1.0F);
            GL11.glDepthMask(true);
            GL11.glEnable(2929);
            GL11.glDisable(2896);
         } else {
            this.unlockedTime = 0L;
            this.showNextHatUnlocked();
         }
      }

      GL11.glPopMatrix();
   }

}

package hats.api;

import hats.api.RenderOnEntityHelper;

public final class Api {

   public static void registerHelper(RenderOnEntityHelper helper) {
      try {
         Class.forName("hats.common.core.ApiHandler").getDeclaredMethod("registerHelper", new Class[]{RenderOnEntityHelper.class}).invoke((Object)null, new Object[]{helper});
      } catch (Exception var2) {
         ;
      }

   }

   public static Object createHatInfo(String hatName, int r, int g, int b, int alpha) {
      try {
         return Class.forName("hats.common.core.ApiHandler").getDeclaredMethod("createHatInfo", new Class[]{String.class, Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE}).invoke((Object)null, new Object[]{hatName, Integer.valueOf(r), Integer.valueOf(g), Integer.valueOf(b), Integer.valueOf(alpha)});
      } catch (Exception var6) {
         return null;
      }
   }

   public static Object createHatInfo(String hatName, int r, int g, int b) {
      try {
         return Class.forName("hats.common.core.ApiHandler").getDeclaredMethod("createHatInfo", new Class[]{String.class, Integer.TYPE, Integer.TYPE, Integer.TYPE}).invoke((Object)null, new Object[]{hatName, Integer.valueOf(r), Integer.valueOf(g), Integer.valueOf(b)});
      } catch (Exception var5) {
         return null;
      }
   }

   public static Object getRandomHatInfoWithServerWeightage(int r, int g, int b, int alpha) {
      try {
         return Class.forName("hats.common.core.ApiHandler").getDeclaredMethod("getRandomHatInfoWithServerWeightage", new Class[]{Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE}).invoke((Object)null, new Object[]{Integer.valueOf(r), Integer.valueOf(g), Integer.valueOf(b), Integer.valueOf(alpha)});
      } catch (Exception var5) {
         return null;
      }
   }

   public static Object getRandomHatInfoWithServerWeightage(int r, int g, int b) {
      try {
         return Class.forName("hats.common.core.ApiHandler").getDeclaredMethod("getRandomHatInfoWithServerWeightage", new Class[]{Integer.TYPE, Integer.TYPE, Integer.TYPE}).invoke((Object)null, new Object[]{Integer.valueOf(r), Integer.valueOf(g), Integer.valueOf(b)});
      } catch (Exception var4) {
         return null;
      }
   }

   public static Object getRandomHatInfo(int r, int g, int b, int alpha) {
      try {
         return Class.forName("hats.common.core.ApiHandler").getDeclaredMethod("getRandomHatInfo", new Class[]{Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE}).invoke((Object)null, new Object[]{Integer.valueOf(r), Integer.valueOf(g), Integer.valueOf(b), Integer.valueOf(alpha)});
      } catch (Exception var5) {
         return null;
      }
   }

   public static Object getRandomHatInfo(int r, int g, int b) {
      try {
         return Class.forName("hats.common.core.ApiHandler").getDeclaredMethod("getRandomHatInfo", new Class[]{Integer.TYPE, Integer.TYPE, Integer.TYPE}).invoke((Object)null, new Object[]{Integer.valueOf(r), Integer.valueOf(g), Integer.valueOf(b)});
      } catch (Exception var4) {
         return null;
      }
   }

   public static void renderHat(Object info, float alpha, float hatScale, float mobRenderScaleX, float mobRenderScaleY, float mobRenderScaleZ, float renderYawOffset, float rotationYaw, float rotationPitch, float rotationRoll, float rotatePointVert, float rotatePointHori, float rotatePointSide, float offsetVert, float offsetHori, float offsetSide, boolean forceRender, boolean bindTexture, float renderTick) {
      try {
         Class.forName("hats.common.core.ApiHandler").getDeclaredMethod("renderHat", new Class[]{Object.class, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Boolean.TYPE, Boolean.TYPE, Float.TYPE}).invoke((Object)null, new Object[]{info, Float.valueOf(alpha), Float.valueOf(hatScale), Float.valueOf(mobRenderScaleX), Float.valueOf(mobRenderScaleY), Float.valueOf(mobRenderScaleZ), Float.valueOf(renderYawOffset), Float.valueOf(rotationYaw), Float.valueOf(rotationPitch), Float.valueOf(rotationRoll), Float.valueOf(rotatePointVert), Float.valueOf(rotatePointHori), Float.valueOf(rotatePointSide), Float.valueOf(offsetVert), Float.valueOf(offsetHori), Float.valueOf(offsetSide), Boolean.valueOf(forceRender), Boolean.valueOf(bindTexture), Float.valueOf(renderTick)});
      } catch (Exception var20) {
         ;
      }

   }
}

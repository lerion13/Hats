package hats.common.trade;

import hats.common.Hats;
import hats.common.packet.PacketString;
import hats.common.packet.PacketTradeOffers;
import hats.common.packet.PacketTradeReadyInfo;
import ichun.common.core.network.PacketHandler;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.Map.Entry;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.StatCollector;

public class TradeInfo {

   public final EntityPlayer trader1;
   public final EntityPlayer trader2;
   public boolean ready1;
   public boolean ready2;
   public boolean trade1;
   public boolean trade2;
   public TreeMap trader1Hats = new TreeMap();
   public ArrayList trader1Items = new ArrayList();
   public TreeMap trader2Hats = new TreeMap();
   public ArrayList trader2Items = new ArrayList();
   public boolean terminate;


   public TradeInfo(EntityPlayer t1, EntityPlayer t2) {
      this.trader1 = t1;
      this.trader2 = t2;
   }

   public TradeInfo initialize() {
      PacketHandler.sendToPlayer(Hats.channels, new PacketString(3, this.trader1.getCommandSenderName()), this.trader2);
      PacketHandler.sendToPlayer(Hats.channels, new PacketString(3, this.trader2.getCommandSenderName()), this.trader1);
      return this;
   }

   public void update() {
      boolean trader1Alive = this.trader1.isEntityAlive();
      boolean trader2Alive = this.trader2.isEntityAlive();
      boolean distanceCheck = (double)this.trader1.getDistanceToEntity(this.trader2) < 16.0D;
      boolean clearSpaceCheck = this.trader1.canEntityBeSeen(this.trader2);
      boolean sameDimension = this.trader1.dimension == this.trader2.dimension;
      if(!trader1Alive || !trader2Alive || !distanceCheck || !clearSpaceCheck || !sameDimension) {
         this.terminate(trader1Alive && trader2Alive?(!distanceCheck?1:(!clearSpaceCheck?2:4)):0, !trader1Alive?this.trader1:(!trader2Alive?this.trader2:null));
      }

   }

   public void terminate(int reason, EntityPlayer terminator) {
      this.terminate = true;
      switch(reason) {
      case 0:
         this.sendTradeMessage(StatCollector.translateToLocal("hats.trade.terminatePrefix") + " " + StatCollector.translateToLocalFormatted("hats.trade.terminate1", new Object[]{StatCollector.translateToLocal("hats.trade.you")}), new EntityPlayer[]{terminator});
         this.sendTradeMessage(StatCollector.translateToLocal("hats.trade.terminatePrefix") + " " + StatCollector.translateToLocalFormatted("hats.trade.terminate1", new Object[]{terminator.getCommandSenderName()}), new EntityPlayer[]{this.getOtherPlayer(terminator)});
         break;
      case 1:
         this.sendTradeMessage(StatCollector.translateToLocal("hats.trade.terminatePrefix") + " " + StatCollector.translateToLocalFormatted("hats.trade.terminate2", new Object[]{this.trader2.getCommandSenderName()}), new EntityPlayer[]{this.trader1});
         this.sendTradeMessage(StatCollector.translateToLocal("hats.trade.terminatePrefix") + " " + StatCollector.translateToLocalFormatted("hats.trade.terminate2", new Object[]{this.trader1.getCommandSenderName()}), new EntityPlayer[]{this.trader2});
         break;
      case 2:
         this.sendTradeMessage(StatCollector.translateToLocal("hats.trade.terminatePrefix") + " " + StatCollector.translateToLocal("hats.trade.terminate3"), new EntityPlayer[]{this.trader1, this.trader2});
         break;
      case 3:
         this.sendTradeMessage(StatCollector.translateToLocal("hats.trade.terminatePrefix") + " " + StatCollector.translateToLocalFormatted("hats.trade.terminate4", new Object[]{terminator.getCommandSenderName()}), new EntityPlayer[]{this.getOtherPlayer(terminator)});
         break;
      case 4:
         this.sendTradeMessage(StatCollector.translateToLocal("hats.trade.terminatePrefix") + " " + StatCollector.translateToLocalFormatted("hats.trade.terminate5", new Object[]{this.trader2.getCommandSenderName()}), new EntityPlayer[]{this.trader1});
         this.sendTradeMessage(StatCollector.translateToLocal("hats.trade.terminatePrefix") + " " + StatCollector.translateToLocalFormatted("hats.trade.terminate5", new Object[]{this.trader1.getCommandSenderName()}), new EntityPlayer[]{this.trader2});
      }

   }

   public void sendTradeMessage(String message, EntityPlayer ... players) {
      EntityPlayer[] arr$ = players;
      int len$ = players.length;

      for(int i$ = 0; i$ < len$; ++i$) {
         EntityPlayer player = arr$[i$];
         PacketHandler.sendToPlayer(Hats.channels, new PacketString(2, message), player);
      }

   }

   public void sendReadyInfo() {
      PacketHandler.sendToPlayer(Hats.channels, new PacketTradeReadyInfo(this.trader1.getCommandSenderName(), this.ready1, this.trader2.getCommandSenderName(), this.ready2), this.trader1);
      PacketHandler.sendToPlayer(Hats.channels, new PacketTradeReadyInfo(this.trader1.getCommandSenderName(), this.ready1, this.trader2.getCommandSenderName(), this.ready2), this.trader2);
   }

   public EntityPlayer getOtherPlayer(EntityPlayer player) {
      return player == this.trader1?this.trader2:this.trader1;
   }

   public boolean isPlayerInTrade(EntityPlayer player) {
      return this.trader1 == player || this.trader2 == player;
   }

   public void receiveTradeInfo(TreeMap hats, ArrayList items, EntityPlayerMP player) {
      PacketHandler.sendToPlayer(Hats.channels, new PacketTradeOffers(hats, items), this.getOtherPlayer(player));
      TreeMap newHats = new TreeMap(hats);
      ArrayList newItems = new ArrayList(items);
      EntityPlayer player1;
      EntityPlayer player2;
      TreeMap oldHats;
      ArrayList oldItems;
      if(player == this.trader1) {
         player1 = this.trader1;
         player2 = this.trader2;
         oldHats = new TreeMap(this.trader1Hats);
         oldItems = new ArrayList(this.trader1Items);
         this.trader1Hats = hats;
         this.trader1Items = items;
      } else {
         player1 = this.trader2;
         player2 = this.trader1;
         oldHats = new TreeMap(this.trader2Hats);
         oldItems = new ArrayList(this.trader2Items);
         this.trader2Hats = hats;
         this.trader2Items = items;
      }

      Iterator ite = newHats.entrySet().iterator();

      Iterator i$;
      Entry is;
      while(ite.hasNext()) {
         Entry ite1 = (Entry)ite.next();
         i$ = oldHats.entrySet().iterator();

         while(i$.hasNext()) {
            is = (Entry)i$.next();
            if(((String)ite1.getKey()).equals(is.getKey())) {
               ite1.setValue(Integer.valueOf(((Integer)ite1.getValue()).intValue() - ((Integer)is.getValue()).intValue()));
               if(((Integer)ite1.getValue()).intValue() <= 0) {
                  ite.remove();
                  break;
               }
            }
         }
      }

      Iterator var18 = oldItems.iterator();

      int var23;
      while(var18.hasNext()) {
         ItemStack var19 = (ItemStack)var18.next();

         for(var23 = newItems.size() - 1; var23 >= 0; --var23) {
            if(ItemStack.areItemStacksEqual((ItemStack)newItems.get(var23), var19)) {
               newItems.remove(var23);
               break;
            }
         }
      }

      var18 = oldHats.entrySet().iterator();

      while(var18.hasNext()) {
         Entry var20 = (Entry)var18.next();
         Iterator var21 = hats.entrySet().iterator();

         while(var21.hasNext()) {
            Entry oldStack = (Entry)var21.next();
            if(((String)var20.getKey()).equals(oldStack.getKey())) {
               var20.setValue(Integer.valueOf(((Integer)var20.getValue()).intValue() - ((Integer)oldStack.getValue()).intValue()));
               if(((Integer)var20.getValue()).intValue() <= 0) {
                  var18.remove();
                  break;
               }
            }
         }
      }

      i$ = items.iterator();

      ItemStack var26;
      while(i$.hasNext()) {
         var26 = (ItemStack)i$.next();

         for(int var25 = oldItems.size() - 1; var25 >= 0; --var25) {
            if(ItemStack.areItemStacksEqual((ItemStack)oldItems.get(var25), var26)) {
               oldItems.remove(var25);
               break;
            }
         }
      }

      for(int var22 = oldItems.size() - 1; var22 >= 0; --var22) {
         for(var23 = newItems.size() - 1; var23 >= 0; --var23) {
            ItemStack var24 = (ItemStack)oldItems.get(var22);
            ItemStack newStack = (ItemStack)newItems.get(var23);
            if(var24.isItemEqual(newStack) && ItemStack.areItemStackTagsEqual(var24, newStack)) {
               int difference = var24.stackSize - newStack.stackSize;
               oldItems.remove(var22);
               newItems.remove(var23);
               ItemStack is1;
               if(difference < 0) {
                  is1 = newStack.copy();
                  is1.stackSize = Math.abs(difference);
                  newItems.add(var23, is1);
               } else {
                  is1 = var24.copy();
                  is1.stackSize = Math.abs(difference);
                  oldItems.add(var22, is1);
               }
            }
         }
      }

      i$ = oldHats.entrySet().iterator();

      while(i$.hasNext()) {
         is = (Entry)i$.next();
         this.sendTradeMessage(StatCollector.translateToLocal("hats.trade.you") + " " + StatCollector.translateToLocal("hats.trade.removed") + " " + EnumChatFormatting.WHITE.toString() + (String)is.getKey(), new EntityPlayer[]{player1});
         this.sendTradeMessage(player1.getCommandSenderName() + " " + StatCollector.translateToLocal("hats.trade.removed") + " " + EnumChatFormatting.WHITE.toString() + (String)is.getKey(), new EntityPlayer[]{player2});
      }

      i$ = oldItems.iterator();

      while(i$.hasNext()) {
         var26 = (ItemStack)i$.next();
         this.sendTradeMessage(StatCollector.translateToLocal("hats.trade.you") + " " + StatCollector.translateToLocal("hats.trade.removed") + " " + EnumChatFormatting.WHITE.toString() + var26.stackSize + " " + var26.getDisplayName(), new EntityPlayer[]{player1});
         this.sendTradeMessage(player1.getCommandSenderName() + " " + StatCollector.translateToLocal("hats.trade.removed") + " " + EnumChatFormatting.WHITE.toString() + var26.stackSize + " " + var26.getDisplayName(), new EntityPlayer[]{player2});
      }

      i$ = newHats.entrySet().iterator();

      while(i$.hasNext()) {
         is = (Entry)i$.next();
         this.sendTradeMessage(StatCollector.translateToLocal("hats.trade.you") + " " + StatCollector.translateToLocal("hats.trade.added") + " " + EnumChatFormatting.WHITE.toString() + (String)is.getKey(), new EntityPlayer[]{player1});
         this.sendTradeMessage(player1.getCommandSenderName() + " " + StatCollector.translateToLocal("hats.trade.added") + " " + EnumChatFormatting.WHITE.toString() + (String)is.getKey(), new EntityPlayer[]{player2});
      }

      i$ = newItems.iterator();

      while(i$.hasNext()) {
         var26 = (ItemStack)i$.next();
         this.sendTradeMessage(StatCollector.translateToLocal("hats.trade.you") + " " + StatCollector.translateToLocal("hats.trade.added") + " " + EnumChatFormatting.WHITE.toString() + var26.stackSize + " " + var26.getDisplayName(), new EntityPlayer[]{player1});
         this.sendTradeMessage(player1.getCommandSenderName() + " " + StatCollector.translateToLocal("hats.trade.added") + " " + EnumChatFormatting.WHITE.toString() + var26.stackSize + " " + var26.getDisplayName(), new EntityPlayer[]{player2});
      }

      this.resetReady();
   }

   public void resetReady() {
      this.toggleReadyTrader1(false);
      this.toggleReadyTrader2(false);
   }

   public void toggleReadyTrader1(boolean shouldReady) {
      if(!shouldReady && this.ready1) {
         this.sendTradeMessage(StatCollector.translateToLocal("hats.trade.notReady"), new EntityPlayer[]{this.trader1});
         this.sendTradeMessage(StatCollector.translateToLocalFormatted("hats.trade.notReadyThem", new Object[]{this.trader1.getCommandSenderName()}), new EntityPlayer[]{this.trader2});
         this.ready1 = false;
         this.trade1 = this.trade2 = false;
         this.sendReadyInfo();
      } else if(shouldReady && !this.ready1) {
         this.sendTradeMessage(StatCollector.translateToLocal("hats.trade.ready"), new EntityPlayer[]{this.trader1});
         this.sendTradeMessage(StatCollector.translateToLocalFormatted("hats.trade.readyThem", new Object[]{this.trader1.getCommandSenderName()}), new EntityPlayer[]{this.trader2});
         this.ready1 = true;
         this.sendReadyInfo();
      }

   }

   public void toggleReadyTrader2(boolean shouldReady) {
      if(!shouldReady && this.ready2) {
         this.sendTradeMessage(StatCollector.translateToLocal("hats.trade.notReady"), new EntityPlayer[]{this.trader2});
         this.sendTradeMessage(StatCollector.translateToLocalFormatted("hats.trade.notReadyThem", new Object[]{this.trader2.getCommandSenderName()}), new EntityPlayer[]{this.trader1});
         this.ready2 = false;
         this.trade1 = this.trade2 = false;
         this.sendReadyInfo();
      } else if(shouldReady && !this.ready2) {
         this.sendTradeMessage(StatCollector.translateToLocal("hats.trade.ready"), new EntityPlayer[]{this.trader2});
         this.sendTradeMessage(StatCollector.translateToLocalFormatted("hats.trade.readyThem", new Object[]{this.trader2.getCommandSenderName()}), new EntityPlayer[]{this.trader1});
         this.ready2 = true;
         this.sendReadyInfo();
      }

   }
}

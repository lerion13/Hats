package hats.common.trade;


public class TradeRequest {

   public final String traderName;
   public int timePending;


   public TradeRequest(String name) {
      this.traderName = name;
   }
}

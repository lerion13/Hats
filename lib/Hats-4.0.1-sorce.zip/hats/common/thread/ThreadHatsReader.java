package hats.common.thread;

import hats.common.Hats;
import hats.common.core.HatHandler;
import ichun.common.core.techne.TC2Info;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ThreadHatsReader extends Thread {

   public final File hatsFolder;
   public final boolean shouldDownload;
   public final boolean loadGuiOnEnd;


   public ThreadHatsReader(File hatsFolder, boolean shouldDownload, boolean loadGuiOnEnd) {
      this.hatsFolder = hatsFolder;
      this.shouldDownload = shouldDownload;
      this.loadGuiOnEnd = loadGuiOnEnd;
      this.setName("Hats Download/Read Hats Thread");
      this.setDaemon(true);
   }

   public void run() {
      int hatCount;
      int len$;
      int i$;
      if(this.shouldDownload) {
         hatCount = 0;

         try {
            URL fav = new URL("http://www.creeperrepo.net/ichun/static/hats.xml");
            DocumentBuilderFactory favs = DocumentBuilderFactory.newInstance();
            DocumentBuilder convertCount = favs.newDocumentBuilder();
            URLConnection files = fav.openConnection();
            files.setConnectTimeout('\uea60');
            files.setReadTimeout('\uea60');
            Document contribHats = convertCount.parse(files.getInputStream());
            NodeList arr$ = contribHats.getElementsByTagName("File");

            for(len$ = 0; len$ < 2; ++len$) {
               for(i$ = 0; i$ < arr$.getLength(); ++i$) {
                  Node file = arr$.item(i$);
                  if(file.getNodeType() == 1) {
                     Element e = (Element)file;
                     String length = e.getElementsByTagName("Path").item(0).getChildNodes().item(0).getNodeValue();
                     long var11 = Long.parseLong(e.getElementsByTagName("Size").item(0).getChildNodes().item(0).getNodeValue());
                     String url = e.getElementsByTagName("URL").item(0).getChildNodes().item(0).getNodeValue();
                     if(var11 > 0L) {
                        url = url.replaceAll(" ", "%20");
                        if(this.downloadResource(new URL(url), new File(this.hatsFolder, length), var11)) {
                           ++hatCount;
                        }
                     }
                  }
               }
            }
         } catch (Exception var19) {
            var19.printStackTrace();
         }

         if(hatCount != 0) {
            Hats.console("Downloaded " + hatCount + " hats from Creeperhost Hat Repository");
         }
      }

      hatCount = 0;
      HatHandler.reloadingHats = true;
      Hats.proxy.clearAllHats();
      File var20 = new File(this.hatsFolder, "/Favourites");
      if(!var20.exists()) {
         var20.mkdirs();
      }

      File[] var21 = var20.listFiles();
      File[] var22 = var21;
      int var24 = var21.length;

      int var26;
      for(var26 = 0; var26 < var24; ++var26) {
         File var27 = var22[var26];
         if(!var27.isDirectory() && (var27.getName().endsWith(".tcn") || var27.getName().endsWith(".tc2"))) {
            File var31 = new File(this.hatsFolder, var27.getName());
            if(!var31.exists()) {
               FileInputStream var32 = null;
               FileOutputStream var35 = null;

               try {
                  var32 = new FileInputStream(var27);
                  var35 = new FileOutputStream(var31);
                  byte[] var33 = new byte[1024];

                  int var37;
                  while((var37 = var32.read(var33)) > 0) {
                     var35.write(var33, 0, var37);
                  }
               } catch (Exception var18) {
                  ;
               }

               try {
                  if(var32 != null) {
                     var32.close();
                  }
               } catch (IOException var17) {
                  ;
               }

               try {
                  if(var35 != null) {
                     var35.close();
                  }
               } catch (IOException var16) {
                  ;
               }
            }
         }
      }

      int var23 = this.convertFolderToTC2(this.hatsFolder);
      if(var23 != 0) {
         Hats.console("Converted " + var23 + (var23 == 1?" hat":" hats") + " from Techne 1 format to Techne 2 format.");
      }

      File[] var25 = this.hatsFolder.listFiles();
      File[] var28 = var25;
      int var30 = var25.length;

      for(len$ = 0; len$ < var30; ++len$) {
         File var36 = var28[len$];
         if(!var36.isDirectory() && HatHandler.readHatFromFile(var36)) {
            ++hatCount;
         }
      }

      var26 = 0;
      File[] var29 = var25;
      len$ = var25.length;

      for(i$ = 0; i$ < len$; ++i$) {
         File var34 = var29[i$];
         if(var34.isDirectory() && !var34.getName().equalsIgnoreCase("Disabled")) {
            if(var34.getName().equalsIgnoreCase("Contributors")) {
               var26 += HatHandler.loadCategory(var34);
               hatCount += var26;
            } else {
               hatCount += HatHandler.loadCategory(var34);
            }
         }
      }

      Hats.console((this.loadGuiOnEnd?"Reloaded ":"Loaded ") + Integer.toString(hatCount) + (hatCount == 1?" hat":" hats. " + var26 + " are contributor hats."));
      if(this.loadGuiOnEnd) {
         HatHandler.reloadAndOpenGui();
      }

      HatHandler.reloadingHats = false;
   }

   private int convertFolderToTC2(File folder) {
      int converted = 0;
      File[] files = folder.listFiles();
      File[] arr$ = files;
      int len$ = files.length;

      for(int i$ = 0; i$ < len$; ++i$) {
         File file = arr$[i$];
         if(file.isDirectory()) {
            converted += this.convertFolderToTC2(file);
         } else if(file.getName().endsWith(".tcn")) {
            TC2Info info = TC2Info.readTechneFile(file);
            if(info != null) {
               info.saveAsFile(new File(file.getParentFile(), file.getName().substring(0, file.getName().length() - 1) + "2"), true);
               file.delete();
               ++converted;
            }
         }
      }

      return converted;
   }

   public boolean downloadResource(URL par1URL, File par2File, long size) throws IOException {
      if(par2File.exists()) {
         if(par2File.length() == size || HatHandler.isHatReadable(par2File)) {
            return false;
         }
      } else if(!par2File.getParentFile().exists()) {
         par2File.getParentFile().mkdirs();
      }

      byte[] var5 = new byte[4096];
      URLConnection con = par1URL.openConnection();
      con.setConnectTimeout(15000);
      con.setReadTimeout(15000);
      DataInputStream var6 = new DataInputStream(con.getInputStream());
      DataOutputStream var7 = new DataOutputStream(new FileOutputStream(par2File));
      boolean var8 = false;

      int var9;
      while((var9 = var6.read(var5)) >= 0) {
         var7.write(var5, 0, var9);
      }

      var6.close();
      var7.close();
      return true;
   }
}

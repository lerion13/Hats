package hats.common.thread;

import com.google.common.io.ByteStreams;
import com.google.gson.Gson;
import hats.client.render.helper.HelperGeneric;
import hats.common.Hats;
import hats.common.core.CommonProxy;
import hats.common.core.HatHandler;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.entity.EntityLivingBase;

public class ThreadGetModMobSupport extends Thread {

   public ThreadGetModMobSupport() {
      this.setName("Hats Mod Mob Support Thread");
      this.setDaemon(true);
   }

   public void run() {
      try {
         Gson e = new Gson();
         Map json;
         if(Hats.config.getInt("readLocalModMobSupport") == 1) {
            FileInputStream i$ = new FileInputStream(new File(HatHandler.hatsFolder, "HatModMobSupport.json"));
            String e1 = new String(ByteStreams.toByteArray(i$));
            i$.close();
            json = (Map)e.fromJson(e1, Map.class);
         } else {
            InputStreamReader i$1 = new InputStreamReader((new URL("https://raw.github.com/iChun/Hats/master/src/main/resources/assets/hats/mod/HatModMobSupport.json")).openStream());
            json = (Map)e.fromJson(i$1, Map.class);
            i$1.close();
         }

         Iterator i$2 = json.entrySet().iterator();

         while(i$2.hasNext()) {
            Entry e2 = (Entry)i$2.next();

            try {
               Class e1 = Class.forName((String)e2.getKey());
               if(EntityLivingBase.class.isAssignableFrom(e1)) {
                  Map vars = (Map)e2.getValue();
                  Boolean bool = (Boolean)vars.get("canUnlockHat");
                  if(bool == null) {
                     bool = Boolean.valueOf(true);
                  }

                  HelperGeneric helperGeneric = new HelperGeneric(e1, bool.booleanValue());
                  helperGeneric.prevRenderYawOffset = getVar(vars.get("prevRenderYawOffset"));
                  helperGeneric.renderYawOffset = getVar(vars.get("renderYawOffset"));
                  helperGeneric.prevRotationYawHead = getVar(vars.get("prevRotationYawHead"));
                  helperGeneric.rotationYawHead = getVar(vars.get("rotationYawHead"));
                  helperGeneric.prevRotationPitch = getVar(vars.get("prevRotationPitch"));
                  helperGeneric.rotationPitch = getVar(vars.get("rotationPitch"));
                  helperGeneric.rotatePointVert = getVar(vars.get("rotatePointVert"));
                  helperGeneric.rotatePointHori = getVar(vars.get("rotatePointHori"));
                  helperGeneric.rotatePointSide = getVar(vars.get("rotatePointSide"));
                  helperGeneric.offsetPointVert = getVar(vars.get("offsetPointVert"));
                  helperGeneric.offsetPointHori = getVar(vars.get("offsetPointHori"));
                  helperGeneric.offsetPointSide = getVar(vars.get("offsetPointSide"));
                  helperGeneric.hatScale = getVar(vars.get("hatScale"));
                  CommonProxy.renderHelpers.put(e1, helperGeneric);
                  Hats.console("Registered " + e1.getName() + " with hat mod mappings.");
               }
            } catch (ClassNotFoundException var9) {
               ;
            }
         }
      } catch (Exception var10) {
         var10.printStackTrace();
      }

   }

   public static Object getVar(Object obj) {
      if(obj == null) {
         return null;
      } else {
         try {
            return Float.valueOf(Float.parseFloat(obj.toString()));
         } catch (NumberFormatException var2) {
            var2.printStackTrace();
            return obj.toString();
         }
      }
   }
}

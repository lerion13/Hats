package hats.common.entity;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import hats.client.core.HatInfoClient;
import hats.common.Hats;
import hats.common.core.CommonProxy;
import hats.common.core.HatInfo;
import morph.api.Api;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

@SideOnly(Side.CLIENT)
public class EntityHat extends Entity {

   public EntityLivingBase parent;
   public EntityLivingBase renderingParent;
   public boolean render;
   public String hatName;
   public HatInfoClient info;
   public int reColour;
   public int prevR;
   public int prevG;
   public int prevB;
   public int prevAlpha;
   private int colourR;
   private int colourG;
   private int colourB;
   private int alpha;
   public long lastUpdate;


   public EntityHat(World par1World) {
      super(par1World);
      this.setSize(0.1F, 0.1F);
      this.hatName = "";
      this.reColour = 0;
      this.prevR = 0;
      this.prevG = 0;
      this.prevB = 0;
      this.prevAlpha = 0;
      this.colourR = 0;
      this.colourG = 0;
      this.colourB = 0;
      this.alpha = 0;
      this.lastUpdate = par1World.getWorldTime();
      super.ignoreFrustumCheck = true;
      super.renderDistanceWeight = 10.0D;
   }

   public EntityHat(World par1World, EntityLivingBase ent, HatInfo hatInfo) {
      super(par1World);
      this.setSize(0.1F, 0.1F);
      this.renderingParent = this.parent = ent;
      this.hatName = hatInfo.hatName;
      this.setLocationAndAngles(this.parent.posX, this.parent.boundingBox.minY, this.parent.posZ, this.parent.rotationYaw, this.parent.rotationPitch);
      this.reColour = 0;
      this.prevR = 0;
      this.prevG = 0;
      this.prevB = 0;
      this.prevAlpha = 0;
      this.colourR = hatInfo.colourR;
      this.colourG = hatInfo.colourG;
      this.colourB = hatInfo.colourB;
      this.alpha = hatInfo.alpha;
      this.lastUpdate = par1World.getWorldTime();
      super.ignoreFrustumCheck = true;
      super.renderDistanceWeight = 10.0D;
   }

   public void onUpdate() {
      this.renderingParent = this.parent;
      this.render = true;
      ++super.ticksExisted;
      if(this.reColour > 0) {
         --this.reColour;
      }

      if(this.parent != null && this.parent.isEntityAlive() && !this.parent.isChild()) {
         if(Hats.hasMorphMod && this.parent instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer)this.parent;
            EntityLivingBase morphEnt = Api.getMorphEntity(player.getCommandSenderName(), true);
            if(morphEnt != null) {
               this.renderingParent = morphEnt;
            }
         }

         this.lastUpdate = super.worldObj.getWorldTime();
         this.validateHatInfo();
      } else {
         this.setDead();
      }
   }

   public int getBrightnessForRender(float par1) {
      return Hats.config.getSessionInt("renderHats") == 13131?15728880:super.getBrightnessForRender(par1);
   }

   public void validateHatInfo() {
      boolean regen = true;
      if(this.info != null && this.info.hatName.equalsIgnoreCase(this.hatName) && this.info.colourR == this.getR() && this.info.colourG == this.getG() && this.info.colourB == this.getB() && this.info.alpha == this.getA() && this.info.prevColourR == this.prevR && this.info.prevColourG == this.prevG && this.info.prevColourB == this.prevB && this.info.prevAlpha == this.prevAlpha) {
         regen = false;
      }

      if(regen) {
         this.info = new HatInfoClient(this.hatName, this.getR(), this.getG(), this.getB(), this.getA());
      }

      this.info.recolour = this.reColour;
      this.info.doNotRender = !this.render;
      this.info.prevColourR = this.prevR;
      this.info.prevColourG = this.prevG;
      this.info.prevColourB = this.prevB;
      this.info.prevAlpha = this.prevAlpha;
   }

   public void setR(int i) {
      this.prevR = this.colourR;
      this.colourR = i;
   }

   public void setG(int i) {
      this.prevG = this.colourG;
      this.colourG = i;
   }

   public void setB(int i) {
      this.prevB = this.colourB;
      this.colourB = i;
   }

   public void setA(int i) {
      this.prevAlpha = this.alpha;
      this.alpha = i;
   }

   public int getR() {
      return this.colourR;
   }

   public int getG() {
      return this.colourG;
   }

   public int getB() {
      return this.colourB;
   }

   public int getA() {
      return this.alpha;
   }

   public void setDead() {
      super.setDead();
      if(Hats.config.getSessionInt("serverHasMod") == 1 && Hats.config.getSessionInt("playerHatsMode") == 4 && this.parent != null) {
         CommonProxy var10000 = Hats.proxy;
         CommonProxy.tickHandlerClient.requestedMobHats.remove(Integer.valueOf(this.parent.getEntityId()));
      }

   }

   public void entityInit() {}

   public boolean writeToNBTOptional(NBTTagCompound par1NBTTagCompound) {
      return false;
   }

   public void readEntityFromNBT(NBTTagCompound nbttagcompound) {}

   public void writeEntityToNBT(NBTTagCompound nbttagcompound) {}
}

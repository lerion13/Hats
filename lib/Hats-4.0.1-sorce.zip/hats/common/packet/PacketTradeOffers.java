package hats.common.packet;

import cpw.mods.fml.common.network.ByteBufUtils;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import hats.client.gui.GuiTradeWindow;
import hats.common.Hats;
import hats.common.core.CommonProxy;
import hats.common.trade.TradeInfo;
import ichun.common.core.network.AbstractPacket;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.Map.Entry;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.MathHelper;

public class PacketTradeOffers extends AbstractPacket {

   public TreeMap tradeHats;
   public ArrayList tradeItems;


   public PacketTradeOffers() {}

   public PacketTradeOffers(TreeMap hats, ArrayList items) {
      this.tradeHats = hats;
      this.tradeItems = items;
   }

   public void writeTo(ByteBuf buffer, Side side) {
      buffer.writeInt(this.tradeHats.size());
      Iterator i$ = this.tradeHats.entrySet().iterator();

      while(i$.hasNext()) {
         Entry is = (Entry)i$.next();
         ByteBufUtils.writeUTF8String(buffer, (String)is.getKey());
         buffer.writeInt(((Integer)is.getValue()).intValue());
      }

      buffer.writeInt(this.tradeItems.size());
      i$ = this.tradeItems.iterator();

      while(i$.hasNext()) {
         ItemStack is1 = (ItemStack)i$.next();
         ByteBufUtils.writeTag(buffer, is1.writeToNBT(new NBTTagCompound()));
      }

   }

   public void readFrom(ByteBuf buffer, Side side) {
      this.tradeHats = new TreeMap();
      this.tradeItems = new ArrayList();
      int hatCount = buffer.readInt();

      int itemCount;
      for(itemCount = 0; itemCount < hatCount; ++itemCount) {
         this.tradeHats.put(ByteBufUtils.readUTF8String(buffer), Integer.valueOf(buffer.readInt()));
      }

      itemCount = buffer.readInt();

      for(int i = 0; i < itemCount; ++i) {
         ItemStack is = ItemStack.loadItemStackFromNBT(ByteBufUtils.readTag(buffer));
         if(is != null) {
            this.tradeItems.add(is);
         }
      }

   }

   public void execute(Side side, EntityPlayer player) {
      if(side.isServer()) {
         CommonProxy var10000 = Hats.proxy;
         Iterator i$ = CommonProxy.tickHandlerServer.activeTrades.iterator();

         while(i$.hasNext()) {
            TradeInfo ti = (TradeInfo)i$.next();
            if(ti.isPlayerInTrade(player)) {
               ti.receiveTradeInfo(this.tradeHats, this.tradeItems, (EntityPlayerMP)player);
               break;
            }
         }
      } else {
         this.handleClient(side, player);
      }

   }

   @SideOnly(Side.CLIENT)
   public void handleClient(Side side, EntityPlayer player) {
      if(Minecraft.getMinecraft().currentScreen instanceof GuiTradeWindow) {
         GuiTradeWindow trade = (GuiTradeWindow)Minecraft.getMinecraft().currentScreen;
         HashMap oldHats = new HashMap(trade.theirHatsForTrade);
         ArrayList oldItems = new ArrayList(trade.theirItemsForTrade);
         trade.theirHatsForTrade = this.tradeHats;
         trade.theirItemsForTrade = this.tradeItems;
         int tradeSize = oldItems.size();
         int hatsSize = oldHats.size();
         trade.theirCanScroll = trade.theirHatsForTrade.size() > 3 || trade.theirItemsForTrade.size() > 6;
         if(!trade.theirCanScroll) {
            trade.theirScrollProg = 0.0F;
         } else {
            float currentBoxes;
            if(tradeSize != trade.theirItemsForTrade.size() && (trade.theirItemsForTrade.size() % 6 == 1 && tradeSize % 6 == 0 || trade.theirItemsForTrade.size() % 6 == 0 && tradeSize % 6 == 1)) {
               currentBoxes = (float)Math.ceil((double)((float)Math.max(trade.theirHatsForTrade.size(), 3) / 3.0F)) * 2.0F + (float)Math.ceil((double)((float)Math.max(tradeSize, 6) / 6.0F)) - 3.0F;
               if(currentBoxes > 0.0F) {
                  trade.theirScrollProg = MathHelper.clamp_float(trade.theirScrollProg * (trade.theirItemsForTrade.size() > tradeSize?currentBoxes / (currentBoxes + 1.0F):currentBoxes / (currentBoxes - 1.0F)), 0.0F, 1.0F);
               }
            } else if(hatsSize != trade.theirHatsForTrade.size() && (trade.theirHatsForTrade.size() % 3 == 1 && hatsSize % 3 == 0 || trade.theirHatsForTrade.size() % 3 == 0 && hatsSize % 3 == 1)) {
               currentBoxes = (float)Math.ceil((double)((float)Math.max(hatsSize, 3) / 3.0F)) * 2.0F + (float)Math.ceil((double)((float)Math.max(trade.theirItemsForTrade.size(), 6) / 6.0F)) - 3.0F;
               if(currentBoxes > 0.0F) {
                  trade.theirScrollProg = MathHelper.clamp_float(trade.theirScrollProg * (trade.theirHatsForTrade.size() > hatsSize?currentBoxes / (currentBoxes + 2.0F):currentBoxes / (currentBoxes - 2.0F)), 0.0F, 1.0F);
               }
            }
         }
      }

   }
}

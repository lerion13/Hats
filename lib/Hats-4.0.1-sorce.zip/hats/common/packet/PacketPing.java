package hats.common.packet;

import cpw.mods.fml.client.FMLClientHandler;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import hats.client.gui.GuiHatSelection;
import hats.client.gui.GuiTradeWindow;
import hats.common.Hats;
import hats.common.core.CommonProxy;
import hats.common.core.HatHandler;
import hats.common.core.TimeActiveInfo;
import hats.common.trade.TradeInfo;
import ichun.common.core.network.AbstractPacket;
import ichun.common.core.network.PacketHandler;
import io.netty.buffer.ByteBuf;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ChatComponentTranslation;

public class PacketPing extends AbstractPacket {

   public int pingId;
   public boolean pingFlag;


   public PacketPing() {}

   public PacketPing(int id, boolean flag) {
      this.pingId = id;
      this.pingFlag = flag;
   }

   public void writeTo(ByteBuf buffer, Side side) {
      buffer.writeInt(this.pingId);
      buffer.writeBoolean(this.pingFlag);
   }

   public void readFrom(ByteBuf buffer, Side side) {
      this.pingId = buffer.readInt();
      this.pingFlag = buffer.readBoolean();
   }

   public void execute(Side side, EntityPlayer player) {
      if(side.isServer()) {
         Iterator i$;
         TradeInfo ti;
         CommonProxy var10000;
         switch(this.pingId) {
         case 0:
            PacketHandler.sendToPlayer(Hats.channels, new PacketPing(0, FMLCommonHandler.instance().getMinecraftServerInstance().getConfigurationManager().func_152596_g(player.getGameProfile())), player);
            break;
         case 1:
            var10000 = Hats.proxy;
            TimeActiveInfo i$1 = (TimeActiveInfo)CommonProxy.tickHandlerServer.playerActivity.get(player.getCommandSenderName());
            if(i$1 != null) {
               i$1.active = this.pingFlag;
            }
            break;
         case 2:
            var10000 = Hats.proxy;
            i$ = CommonProxy.tickHandlerServer.activeTrades.iterator();

            do {
               if(!i$.hasNext()) {
                  return;
               }

               ti = (TradeInfo)i$.next();
            } while(!ti.isPlayerInTrade(player));

            ti.terminate(3, player);
            break;
         case 3:
            var10000 = Hats.proxy;
            i$ = CommonProxy.tickHandlerServer.activeTrades.iterator();

            do {
               if(!i$.hasNext()) {
                  return;
               }

               ti = (TradeInfo)i$.next();
            } while(!ti.isPlayerInTrade(player));

            if(ti.trader1 == player) {
               ti.toggleReadyTrader1(this.pingFlag);
            } else {
               ti.toggleReadyTrader2(this.pingFlag);
            }
            break;
         case 4:
            var10000 = Hats.proxy;
            i$ = CommonProxy.tickHandlerServer.activeTrades.iterator();

            while(i$.hasNext()) {
               ti = (TradeInfo)i$.next();
               if(ti.isPlayerInTrade(player)) {
                  if(ti.trader1 == player) {
                     ti.trade1 = true;
                  } else {
                     ti.trade2 = true;
                  }

                  PacketHandler.sendToPlayer(Hats.channels, new PacketPing(2, false), ti.getOtherPlayer(player));
                  break;
               }
            }
         }
      } else {
         this.handleClient();
      }

   }

   @SideOnly(Side.CLIENT)
   public void handleClient() {
      switch(this.pingId) {
      case 0:
         if(this.pingFlag) {
            FMLClientHandler.instance().displayGuiScreen(Minecraft.getMinecraft().thePlayer, new GuiHatSelection(Minecraft.getMinecraft().thePlayer));
         } else {
            Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentTranslation("hats.serverOnCommandGiverMode", new Object[0]));
         }
         break;
      case 1:
         HatHandler.populateHatsList("");
         break;
      case 2:
         if(Minecraft.getMinecraft().currentScreen instanceof GuiTradeWindow) {
            GuiTradeWindow trade = (GuiTradeWindow)Minecraft.getMinecraft().currentScreen;
            trade.pointOfNoReturn = true;
         }
         break;
      case 3:
         if(Minecraft.getMinecraft().currentScreen instanceof GuiTradeWindow) {
            FMLCommonHandler.instance().showGuiScreen((Object)null);
            Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentTranslation("hats.trade.success", new Object[0]));
         }
      }

   }
}

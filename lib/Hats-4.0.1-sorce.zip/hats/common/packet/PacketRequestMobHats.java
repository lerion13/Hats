package hats.common.packet;

import cpw.mods.fml.relauncher.Side;
import hats.common.Hats;
import hats.common.core.CommonProxy;
import hats.common.packet.PacketMobHatsList;
import ichun.common.core.network.AbstractPacket;
import ichun.common.core.network.PacketHandler;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;

public class PacketRequestMobHats extends AbstractPacket {

   public ArrayList entIds;


   public PacketRequestMobHats() {}

   public PacketRequestMobHats(ArrayList list) {
      this.entIds = new ArrayList(list);
   }

   public void writeTo(ByteBuf buffer, Side side) {
      Iterator i$ = this.entIds.iterator();

      while(i$.hasNext()) {
         Integer i = (Integer)i$.next();
         buffer.writeInt(i.intValue());
      }

      buffer.writeInt(-2);
   }

   public void readFrom(ByteBuf buffer, Side side) {
      this.entIds = new ArrayList();

      for(int id = buffer.readInt(); id != -2; id = buffer.readInt()) {
         this.entIds.add(Integer.valueOf(id));
      }

   }

   public void execute(Side side, EntityPlayer player) {
      ArrayList ids = new ArrayList();
      ArrayList names = new ArrayList();
      Iterator i$ = this.entIds.iterator();

      while(i$.hasNext()) {
         Integer id = (Integer)i$.next();
         Entity ent = player.worldObj.getEntityByID(id.intValue());
         if(ent instanceof EntityLivingBase) {
            CommonProxy var10000 = Hats.proxy;
            String hatName = (String)CommonProxy.tickHandlerServer.mobHats.get((EntityLivingBase)ent);
            if(hatName != null) {
               ids.add(id);
               names.add(hatName.trim());
            }
         }
      }

      ids.add(Integer.valueOf(-2));
      PacketHandler.sendToPlayer(Hats.channels, new PacketMobHatsList(ids, names), player);
   }
}

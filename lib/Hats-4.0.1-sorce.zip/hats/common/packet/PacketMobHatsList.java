package hats.common.packet;

import cpw.mods.fml.common.network.ByteBufUtils;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import hats.common.Hats;
import hats.common.core.CommonProxy;
import hats.common.core.HatInfo;
import hats.common.entity.EntityHat;
import ichun.common.core.network.AbstractPacket;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;

public class PacketMobHatsList extends AbstractPacket {

   public ArrayList mobIds = new ArrayList();
   public ArrayList hatNames = new ArrayList();


   public PacketMobHatsList() {}

   public PacketMobHatsList(ArrayList ids, ArrayList names) {
      this.mobIds = ids;
      this.hatNames = names;
   }

   public void writeTo(ByteBuf buffer, Side side) {
      try {
         for(int e = 0; e < this.mobIds.size(); ++e) {
            buffer.writeInt(((Integer)this.mobIds.get(e)).intValue());
            if(((Integer)this.mobIds.get(e)).intValue() != -2) {
               ByteBufUtils.writeUTF8String(buffer, (String)this.hatNames.get(e));
            }
         }
      } catch (Exception var4) {
         var4.printStackTrace();
      }

      buffer.writeInt(-2);
   }

   public void readFrom(ByteBuf buffer, Side side) {
      for(int id = buffer.readInt(); id != -2; id = buffer.readInt()) {
         this.mobIds.add(Integer.valueOf(id));
         this.hatNames.add(ByteBufUtils.readUTF8String(buffer));
      }

   }

   public void execute(Side side, EntityPlayer player) {
      this.handleClient(side, player);
   }

   @SideOnly(Side.CLIENT)
   public void handleClient(Side side, EntityPlayer player) {
      for(int i = 0; i < Math.min(this.mobIds.size(), this.hatNames.size()); ++i) {
         Entity ent = Minecraft.getMinecraft().theWorld.getEntityByID(((Integer)this.mobIds.get(i)).intValue());
         if(ent != null && ent instanceof EntityLivingBase) {
            HatInfo hatInfo = new HatInfo((String)this.hatNames.get(i));
            EntityHat hat = new EntityHat(ent.worldObj, (EntityLivingBase)ent, hatInfo);
            CommonProxy var10000 = Hats.proxy;
            CommonProxy.tickHandlerClient.mobHats.put(Integer.valueOf(ent.getEntityId()), hat);
            ent.worldObj.spawnEntityInWorld(hat);
         }
      }

   }
}

package hats.common.packet;

import cpw.mods.fml.common.network.ByteBufUtils;
import cpw.mods.fml.relauncher.Side;
import hats.common.Hats;
import hats.common.core.CommonProxy;
import hats.common.core.HatInfo;
import hats.common.entity.EntityHat;
import ichun.common.core.network.AbstractPacket;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.entity.player.EntityPlayer;

public class PacketWornHatList extends AbstractPacket {

   public ArrayList playerNames;


   public PacketWornHatList() {}

   public PacketWornHatList(ArrayList names) {
      this.playerNames = names;
   }

   public void writeTo(ByteBuf buffer, Side side) {
      Iterator i$ = this.playerNames.iterator();

      while(i$.hasNext()) {
         String s = (String)i$.next();
         CommonProxy var10000 = Hats.proxy;
         HatInfo hat = (HatInfo)CommonProxy.playerWornHats.get(s);
         if(hat == null) {
            hat = new HatInfo();
         }

         ByteBufUtils.writeUTF8String(buffer, s);
         ByteBufUtils.writeUTF8String(buffer, hat.hatName);
         buffer.writeInt(hat.colourR);
         buffer.writeInt(hat.colourG);
         buffer.writeInt(hat.colourB);
         buffer.writeInt(hat.alpha);
      }

      ByteBufUtils.writeUTF8String(buffer, "#endPacket");
   }

   public void readFrom(ByteBuf buffer, Side side) {
      for(String name = ByteBufUtils.readUTF8String(buffer); !name.equalsIgnoreCase("#endPacket"); name = ByteBufUtils.readUTF8String(buffer)) {
         String hatName = ByteBufUtils.readUTF8String(buffer);
         int r = buffer.readInt();
         int g = buffer.readInt();
         int b = buffer.readInt();
         int a = buffer.readInt();
         CommonProxy var10000 = Hats.proxy;
         CommonProxy.tickHandlerClient.playerWornHats.put(name, new HatInfo(hatName, r, g, b, a));
         var10000 = Hats.proxy;
         EntityHat hat = (EntityHat)CommonProxy.tickHandlerClient.hats.get(name);
         if(hat != null) {
            if(hatName.equalsIgnoreCase(hat.hatName)) {
               hat.reColour = 20;
            }

            hat.hatName = hatName;
            hat.setR(r);
            hat.setG(g);
            hat.setB(b);
            hat.setA(a);
         }
      }

   }

   public void execute(Side side, EntityPlayer player) {}
}

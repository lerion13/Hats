package hats.common.packet;

import cpw.mods.fml.client.FMLClientHandler;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.network.ByteBufUtils;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import hats.client.gui.GuiHatSelection;
import hats.client.gui.GuiHatUnlocked;
import hats.client.gui.GuiTradeWindow;
import hats.common.Hats;
import hats.common.core.CommonProxy;
import hats.common.trade.TradeInfo;
import hats.common.trade.TradeRequest;
import ichun.common.core.network.AbstractPacket;
import ichun.common.core.network.PacketHandler;
import io.netty.buffer.ByteBuf;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.StatCollector;

public class PacketString extends AbstractPacket {

   public int pingId;
   public String pingString;


   public PacketString() {}

   public PacketString(int id, String str) {
      this.pingId = id;
      this.pingString = str;
   }

   public void writeTo(ByteBuf buffer, Side side) {
      buffer.writeInt(this.pingId);
      ByteBufUtils.writeUTF8String(buffer, this.pingString);
   }

   public void readFrom(ByteBuf buffer, Side side) {
      this.pingId = buffer.readInt();
      this.pingString = ByteBufUtils.readUTF8String(buffer);
   }

   public void execute(Side side, EntityPlayer player) {
      if(side.isServer()) {
         String i$1;
         CommonProxy var10000;
         switch(this.pingId) {
         case 0:
            i$1 = this.pingString;
            EntityPlayerMP ti2 = FMLCommonHandler.instance().getMinecraftServerInstance().getConfigurationManager().func_152612_a(i$1);
            if(ti2 != null && ti2.isEntityAlive() && (double)ti2.getDistanceToEntity(player) < 16.0D && ti2.canEntityBeSeen(player) && ti2.dimension == player.dimension) {
               var10000 = Hats.proxy;
               TradeRequest plyr1 = (TradeRequest)CommonProxy.tickHandlerServer.playerTradeRequests.get(player.getCommandSenderName());
               if(plyr1 != null && plyr1.traderName.equalsIgnoreCase(ti2.getCommandSenderName())) {
                  var10000 = Hats.proxy;
                  CommonProxy.tickHandlerServer.initializeTrade((EntityPlayerMP)player, ti2);
               } else {
                  var10000 = Hats.proxy;
                  TradeRequest tr = (TradeRequest)CommonProxy.tickHandlerServer.playerTradeRequests.get(ti2.getCommandSenderName());
                  if(tr == null || !tr.traderName.equalsIgnoreCase(player.getCommandSenderName())) {
                     var10000 = Hats.proxy;
                     CommonProxy.tickHandlerServer.playerTradeRequests.put(ti2.getCommandSenderName(), new TradeRequest(player.getCommandSenderName()));
                     PacketHandler.sendToPlayer(Hats.channels, new PacketString(1, player.getCommandSenderName()), ti2);
                  }
               }
            } else {
               player.addChatMessage(new ChatComponentTranslation("hats.trade.cannotFindTrader", new Object[]{i$1}));
            }
            break;
         case 1:
            i$1 = this.pingString;
            var10000 = Hats.proxy;
            TradeRequest ti1 = (TradeRequest)CommonProxy.tickHandlerServer.playerTradeRequests.get(player.getCommandSenderName());
            if(ti1 == null) {
               player.addChatMessage(new ChatComponentTranslation("hats.trade.cannotAcceptTrade", new Object[0]));
            } else {
               EntityPlayerMP plyr = FMLCommonHandler.instance().getMinecraftServerInstance().getConfigurationManager().func_152612_a(i$1);
               if(plyr != null && plyr.isEntityAlive() && (double)plyr.getDistanceToEntity(player) < 16.0D && plyr.canEntityBeSeen(player) && plyr.dimension == player.dimension) {
                  var10000 = Hats.proxy;
                  CommonProxy.tickHandlerServer.playerTradeRequests.remove(player.getCommandSenderName());
                  var10000 = Hats.proxy;
                  CommonProxy.tickHandlerServer.initializeTrade((EntityPlayerMP)player, plyr);
               } else {
                  player.addChatMessage(new ChatComponentTranslation("hats.trade.cannotAcceptTrade", new Object[0]));
               }
            }
            break;
         case 2:
            var10000 = Hats.proxy;
            Iterator i$ = CommonProxy.tickHandlerServer.activeTrades.iterator();

            while(i$.hasNext()) {
               TradeInfo ti = (TradeInfo)i$.next();
               if(ti.isPlayerInTrade(player)) {
                  Hats.console("[In-Trade] " + this.pingString, false);
                  ti.sendTradeMessage(this.pingString, new EntityPlayer[]{ti.getOtherPlayer(player)});
                  break;
               }
            }
         case 3:
         case 4:
         }
      } else {
         this.handleClient();
      }

   }

   @SideOnly(Side.CLIENT)
   public void handleClient() {
      CommonProxy var10000;
      switch(this.pingId) {
      case 0:
         var10000 = Hats.proxy;
         if(CommonProxy.tickHandlerClient.serverHats.get(this.pingString) == null) {
            var10000 = Hats.proxy;
            CommonProxy.tickHandlerClient.serverHats.put(this.pingString, Integer.valueOf(1));
            var10000 = Hats.proxy;
            if(CommonProxy.tickHandlerClient.guiHatUnlocked == null) {
               var10000 = Hats.proxy;
               CommonProxy.tickHandlerClient.guiHatUnlocked = new GuiHatUnlocked(Minecraft.getMinecraft());
            }

            var10000 = Hats.proxy;
            CommonProxy.tickHandlerClient.guiHatUnlocked.queueHatUnlocked(this.pingString);
         } else {
            var10000 = Hats.proxy;
            CommonProxy var10002 = Hats.proxy;
            CommonProxy.tickHandlerClient.serverHats.put(this.pingString, Integer.valueOf(((Integer)CommonProxy.tickHandlerClient.serverHats.get(this.pingString)).intValue() + 1));
         }
         break;
      case 1:
         var10000 = Hats.proxy;
         CommonProxy.tickHandlerClient.tradeReq = this.pingString;
         var10000 = Hats.proxy;
         CommonProxy.tickHandlerClient.tradeReqTimeout = 1200;
         Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("random.successful_hit"), 1.0F));
         var10000 = Hats.proxy;
         CommonProxy var10001 = Hats.proxy;
         CommonProxy.tickHandlerClient.guiNewTradeReq.queueHatUnlocked(CommonProxy.tickHandlerClient.tradeReq);
         if(Minecraft.getMinecraft().currentScreen instanceof GuiHatSelection) {
            ((GuiHatSelection)Minecraft.getMinecraft().currentScreen).updateButtonList();
         }
         break;
      case 2:
         if(Minecraft.getMinecraft().currentScreen instanceof GuiTradeWindow) {
            GuiTradeWindow trade = (GuiTradeWindow)Minecraft.getMinecraft().currentScreen;
            trade.chatMessages.add(this.pingString);
            if(trade.chatMessages.size() > 1 && ((String)trade.chatMessages.get(trade.chatMessages.size() - 2)).startsWith(this.pingString) && (this.pingString.contains(StatCollector.translateToLocal("hats.trade.added")) || this.pingString.contains(StatCollector.translateToLocal("hats.trade.removed"))) && !this.pingString.contains(":")) {
               if(((String)trade.chatMessages.get(trade.chatMessages.size() - 2)).equals(this.pingString)) {
                  trade.chatMessages.remove(trade.chatMessages.size() - 1);
                  trade.chatMessages.remove(trade.chatMessages.size() - 1);
                  trade.chatMessages.add(this.pingString + " (2)");
               } else {
                  String countStr = ((String)trade.chatMessages.get(trade.chatMessages.size() - 2)).substring(this.pingString.length() + 2, ((String)trade.chatMessages.get(trade.chatMessages.size() - 2)).length() - 1);
                  int count = 2;

                  try {
                     count = Integer.parseInt(countStr);
                  } catch (NumberFormatException var5) {
                     ;
                  }

                  trade.chatMessages.remove(trade.chatMessages.size() - 1);
                  trade.chatMessages.remove(trade.chatMessages.size() - 1);
                  trade.chatMessages.add(this.pingString + " (" + Integer.toString(count + 1) + ")");
               }
            }
         }
         break;
      case 3:
         FMLClientHandler.instance().displayGuiScreen(Minecraft.getMinecraft().thePlayer, new GuiTradeWindow(this.pingString));
         var10000 = Hats.proxy;
         CommonProxy.tickHandlerClient.tradeReq = null;
         var10000 = Hats.proxy;
         CommonProxy.tickHandlerClient.tradeReqTimeout = 0;
      case 4:
      }

   }
}

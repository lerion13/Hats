package hats.common.packet;

import cpw.mods.fml.common.network.ByteBufUtils;
import cpw.mods.fml.relauncher.Side;
import hats.common.core.HatHandler;
import ichun.common.core.network.AbstractPacket;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayer;

public class PacketRequestHat extends AbstractPacket {

   public String hatName;


   public PacketRequestHat() {}

   public PacketRequestHat(String name) {
      this.hatName = name;
   }

   public void writeTo(ByteBuf buffer, Side side) {
      ByteBufUtils.writeUTF8String(buffer, this.hatName);
   }

   public void readFrom(ByteBuf buffer, Side side) {
      this.hatName = ByteBufUtils.readUTF8String(buffer);
   }

   public void execute(Side side, EntityPlayer player) {
      HatHandler.sendHat(this.hatName, side.isServer()?player:null);
   }
}

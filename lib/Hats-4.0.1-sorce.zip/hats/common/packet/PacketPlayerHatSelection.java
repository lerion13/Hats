package hats.common.packet;

import cpw.mods.fml.common.network.ByteBufUtils;
import cpw.mods.fml.relauncher.Side;
import hats.common.Hats;
import hats.common.core.CommonProxy;
import hats.common.core.HatHandler;
import hats.common.core.HatInfo;
import ichun.common.core.network.AbstractPacket;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;

public class PacketPlayerHatSelection extends AbstractPacket {

   public String hatName;
   public int r;
   public int g;
   public int b;
   public int a;


   public PacketPlayerHatSelection() {}

   public PacketPlayerHatSelection(String name, int R, int G, int B, int A) {
      this.hatName = name;
      this.r = R;
      this.g = G;
      this.b = B;
      this.a = A;
   }

   public void writeTo(ByteBuf buffer, Side side) {
      ByteBufUtils.writeUTF8String(buffer, this.hatName);
      buffer.writeInt(this.r);
      buffer.writeInt(this.g);
      buffer.writeInt(this.b);
      buffer.writeInt(this.a);
   }

   public void readFrom(ByteBuf buffer, Side side) {
      this.hatName = ByteBufUtils.readUTF8String(buffer);
      this.r = buffer.readInt();
      this.g = buffer.readInt();
      this.b = buffer.readInt();
      this.a = buffer.readInt();
   }

   public void execute(Side side, EntityPlayer player) {
      CommonProxy var10000 = Hats.proxy;
      CommonProxy.playerWornHats.put(player.getCommandSenderName(), new HatInfo(this.hatName, this.r, this.g, this.b, this.a));
      if(HatHandler.hasHat(this.hatName)) {
         NBTTagCompound persistentTag = player.getEntityData().getCompoundTag("PlayerPersisted");
         persistentTag.setString("Hats_wornHat", this.hatName);
         persistentTag.setInteger("Hats_colourR", this.r);
         persistentTag.setInteger("Hats_colourG", this.g);
         persistentTag.setInteger("Hats_colourB", this.b);
         persistentTag.setInteger("Hats_alpha", this.a);
         player.getEntityData().setTag("PlayerPersisted", persistentTag);
         Hats.proxy.sendPlayerListOfWornHats(player, false);
      } else {
         HatHandler.requestHat(this.hatName, player);
      }

   }
}

package hats.common.core;

import cpw.mods.fml.common.FMLCommonHandler;
import hats.client.core.TickHandlerClient;
import hats.client.render.helper.HelperBat;
import hats.client.render.helper.HelperBlaze;
import hats.client.render.helper.HelperChicken;
import hats.client.render.helper.HelperCow;
import hats.client.render.helper.HelperCreeper;
import hats.client.render.helper.HelperEnderman;
import hats.client.render.helper.HelperGhast;
import hats.client.render.helper.HelperGiantZombie;
import hats.client.render.helper.HelperHorse;
import hats.client.render.helper.HelperOcelot;
import hats.client.render.helper.HelperPig;
import hats.client.render.helper.HelperPlayer;
import hats.client.render.helper.HelperSheep;
import hats.client.render.helper.HelperSkeleton;
import hats.client.render.helper.HelperSlime;
import hats.client.render.helper.HelperSpider;
import hats.client.render.helper.HelperSquid;
import hats.client.render.helper.HelperVillager;
import hats.client.render.helper.HelperWither;
import hats.client.render.helper.HelperWolf;
import hats.client.render.helper.HelperZombie;
import hats.common.Hats;
import hats.common.core.CommandHats;
import hats.common.core.HatHandler;
import hats.common.core.TickHandlerServer;
import hats.common.packet.PacketHatFragment;
import hats.common.packet.PacketKingOfTheHatInfo;
import hats.common.packet.PacketMobHatsList;
import hats.common.packet.PacketPing;
import hats.common.packet.PacketPlayerHatSelection;
import hats.common.packet.PacketRequestHat;
import hats.common.packet.PacketRequestMobHats;
import hats.common.packet.PacketSession;
import hats.common.packet.PacketString;
import hats.common.packet.PacketTradeOffers;
import hats.common.packet.PacketTradeReadyInfo;
import hats.common.packet.PacketWornHatList;
import hats.common.thread.ThreadGetModMobSupport;
import hats.common.thread.ThreadHatsReader;
import ichun.common.core.network.ChannelHandler;
import ichun.common.core.network.PacketHandler;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import net.minecraft.command.CommandHandler;
import net.minecraft.command.ICommandManager;
import net.minecraft.entity.boss.EntityWither;
import net.minecraft.entity.monster.EntityBlaze;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntityGiantZombie;
import net.minecraft.entity.monster.EntitySkeleton;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.monster.EntitySpider;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.passive.EntityBat;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.entity.passive.EntityCow;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.passive.EntityOcelot;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;

public class CommonProxy {

   public static HashMap renderHelpers = new HashMap();
   public static HashMap playerWornHats = new HashMap();
   public static TickHandlerClient tickHandlerClient;
   public static TickHandlerServer tickHandlerServer;


   public void initCommands(MinecraftServer server) {
      ICommandManager manager = server.getCommandManager();
      if(manager instanceof CommandHandler) {
         CommandHandler handler = (CommandHandler)manager;
         handler.registerCommand(new CommandHats());
      }

   }

   public void initMod() {
      this.getHats();
      renderHelpers.put(EntityBat.class, new HelperBat());
      renderHelpers.put(EntityBlaze.class, new HelperBlaze());
      renderHelpers.put(EntityChicken.class, new HelperChicken());
      renderHelpers.put(EntityCow.class, new HelperCow());
      renderHelpers.put(EntityCreeper.class, new HelperCreeper());
      renderHelpers.put(EntityEnderman.class, new HelperEnderman());
      renderHelpers.put(EntityGhast.class, new HelperGhast());
      renderHelpers.put(EntityGiantZombie.class, new HelperGiantZombie());
      renderHelpers.put(EntityHorse.class, new HelperHorse());
      renderHelpers.put(EntityOcelot.class, new HelperOcelot());
      renderHelpers.put(EntityPig.class, new HelperPig());
      renderHelpers.put(EntityPlayer.class, new HelperPlayer());
      renderHelpers.put(EntitySheep.class, new HelperSheep());
      renderHelpers.put(EntitySkeleton.class, new HelperSkeleton());
      renderHelpers.put(EntitySlime.class, new HelperSlime());
      renderHelpers.put(EntitySpider.class, new HelperSpider());
      renderHelpers.put(EntitySquid.class, new HelperSquid());
      renderHelpers.put(EntityVillager.class, new HelperVillager());
      renderHelpers.put(EntityWolf.class, new HelperWolf());
      renderHelpers.put(EntityZombie.class, new HelperZombie());
      renderHelpers.put(EntityWither.class, new HelperWither());
      this.getHatMobModSupport();
      Hats.channels = ChannelHandler.getChannelHandlers("Hats", new Class[]{PacketPlayerHatSelection.class, PacketRequestHat.class, PacketPing.class, PacketString.class, PacketRequestMobHats.class, PacketSession.class, PacketTradeReadyInfo.class, PacketWornHatList.class, PacketMobHatsList.class, PacketKingOfTheHatInfo.class, PacketTradeOffers.class, PacketHatFragment.class});
   }

   public void getHatMobModSupport() {
      if(Hats.config.getInt("modMobSupport") == 1) {
         (new ThreadGetModMobSupport()).start();
      }

   }

   public void initRenderersAndTextures() {}

   public void initSounds() {}

   public void initTickHandlers() {
      tickHandlerServer = new TickHandlerServer();
      FMLCommonHandler.instance().bus().register(tickHandlerServer);
   }

   public void getHats() {
      (new ThreadHatsReader(HatHandler.hatsFolder, true, false)).start();
   }

   public void getHatsAndOpenGui() {}

   public void clearAllHats() {
      HatHandler.getHatNames().clear();
      HatHandler.checksums.clear();
      HatHandler.categories.clear();
   }

   public void openHatsGui() {}

   public void loadHatFile(File file) {
      String hatName = file.getName().substring(0, file.getName().length() - 4).toLowerCase();
      HatHandler.getActualHatNamesMap().put(file, hatName);
   }

   public void remap(String duplicate, String original) {
      File file = null;
      Iterator i$ = HatHandler.getActualHatNamesMap().entrySet().iterator();

      while(i$.hasNext()) {
         Entry e = (Entry)i$.next();
         if(((String)e.getValue()).equalsIgnoreCase(original)) {
            file = (File)e.getKey();
            break;
         }
      }

      if(file != null) {
         HatHandler.getActualHatNamesMap().put(file, duplicate);
      }

   }

   public void sendPlayerListOfWornHats(EntityPlayer player, boolean sendAllPlayerHatInfo) {
      this.sendPlayerListOfWornHats(player, sendAllPlayerHatInfo, true);
   }

   public void sendPlayerListOfWornHats(EntityPlayer player, boolean sendAllPlayerHatInfo, boolean ignorePlayer) {
      ArrayList playerNames = new ArrayList();
      if(sendAllPlayerHatInfo) {
         CommonProxy var10000 = Hats.proxy;
         Iterator packet = playerWornHats.entrySet().iterator();

         while(packet.hasNext()) {
            Entry e = (Entry)packet.next();
            playerNames.add(e.getKey());
         }

         PacketHandler.sendToPlayer(Hats.channels, new PacketWornHatList(playerNames), player);
      } else {
         playerNames.add(player.getCommandSenderName());
         PacketWornHatList packet1 = new PacketWornHatList(playerNames);
         if(ignorePlayer) {
            PacketHandler.sendToAllExcept(Hats.channels, packet1, player);
         } else {
            PacketHandler.sendToAll(Hats.channels, packet1);
         }
      }

   }

}

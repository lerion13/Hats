package hats.common.core;

import cpw.mods.fml.common.FMLCommonHandler;
import hats.common.Hats;
import hats.common.core.CommonProxy;
import hats.common.core.HatHandler;
import hats.common.core.HatInfo;
import java.util.Arrays;
import java.util.List;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.StatCollector;

public class CommandHats extends CommandBase {

   public String getCommandName() {
      return "hats";
   }

   public String getCommandUsage(ICommandSender par1ICommandSender) {
      return "/" + this.getCommandName() + "           " + StatCollector.translateToLocal("hats.command.help");
   }

   public List getCommandAliases() {
      return Arrays.asList(new String[]{"hat"});
   }

   public void processCommand(ICommandSender icommandsender, String[] astring) {
      if(astring.length <= 0) {
         throw new WrongUsageException(this.getUsageString(), new Object[0]);
      } else {
         String command = astring[0];
         if(astring.length == 1) {
            if("send".startsWith(command.toLowerCase())) {
               icommandsender.addChatMessage(new ChatComponentTranslation("§c" + StatCollector.translateToLocal("hats.command.help.send"), new Object[0]));
            } else if("set".startsWith(command.toLowerCase())) {
               icommandsender.addChatMessage(new ChatComponentTranslation("§c" + StatCollector.translateToLocal("hats.command.help.set"), new Object[0]));
            } else if("unlock".startsWith(command.toLowerCase())) {
               icommandsender.addChatMessage(new ChatComponentTranslation("§c" + StatCollector.translateToLocal("hats.command.help.unlock"), new Object[0]));
            }
         } else if(astring.length == 2) {
            if("send".startsWith(command.toLowerCase())) {
               icommandsender.addChatMessage(new ChatComponentTranslation("§c" + StatCollector.translateToLocal("hats.command.help.send"), new Object[0]));
            } else if("set".startsWith(command.toLowerCase())) {
               icommandsender.addChatMessage(new ChatComponentTranslation("§c" + StatCollector.translateToLocal("hats.command.help.set"), new Object[0]));
            } else if("unlock".startsWith(command.toLowerCase())) {
               icommandsender.addChatMessage(new ChatComponentTranslation("§c" + StatCollector.translateToLocal("hats.command.help.unlock"), new Object[0]));
            }
         } else if(astring.length >= 3) {
            String playerName = astring[1];
            StringBuilder sb = new StringBuilder();

            for(int hatName = 2; hatName < astring.length; ++hatName) {
               sb.append(astring[hatName]);
               sb.append(" ");
            }

            String var8 = HatHandler.getHatStartingWith(sb.toString().trim());
            EntityPlayerMP player = FMLCommonHandler.instance().getMinecraftServerInstance().getConfigurationManager().func_152612_a(playerName);
            if(player == null) {
               icommandsender.addChatMessage(new ChatComponentTranslation("§c" + StatCollector.translateToLocalFormatted("hats.command.notOnline", new Object[]{playerName}), new Object[0]));
               return;
            }

            if(!HatHandler.hasHat(var8)) {
               icommandsender.addChatMessage(new ChatComponentTranslation("§c" + StatCollector.translateToLocalFormatted("hats.command.hatDoesNotExist", new Object[]{var8}), new Object[0]));
               return;
            }

            if("send".startsWith(command.toLowerCase())) {
               if(Hats.config.getInt("allowSendingOfHats") == 0) {
                  icommandsender.addChatMessage(new ChatComponentTranslation("§c" + StatCollector.translateToLocal("hats.command.serverDisabledHatSending"), new Object[0]));
                  return;
               }

               icommandsender.addChatMessage(new ChatComponentTranslation("§7" + StatCollector.translateToLocalFormatted("hats.command.sendToPlayer", new Object[]{var8, player.getCommandSenderName()}), new Object[0]));
               HatHandler.sendHat(var8, player);
            } else if("set".startsWith(command.toLowerCase())) {
               icommandsender.addChatMessage(new ChatComponentTranslation("§7" + StatCollector.translateToLocalFormatted("hats.command.setPlayerHat", new Object[]{var8, player.getCommandSenderName()}), new Object[0]));
               CommonProxy var10000 = Hats.proxy;
               CommonProxy.playerWornHats.put(player.getCommandSenderName(), new HatInfo(var8.toLowerCase(), 255, 255, 255, 255));
               Hats.proxy.sendPlayerListOfWornHats(player, false, false);
            } else if("unlock".startsWith(command.toLowerCase())) {
               if(Hats.config.getSessionInt("playerHatsMode") >= 4) {
                  if(player.capabilities.isCreativeMode) {
                     icommandsender.addChatMessage(new ChatComponentTranslation("§7" + StatCollector.translateToLocalFormatted("hats.command.playerIsInCreative", new Object[]{player.getCommandSenderName()}), new Object[0]));
                  } else {
                     icommandsender.addChatMessage(new ChatComponentTranslation("§7" + StatCollector.translateToLocalFormatted("hats.command.unlockHatForPlayer", new Object[]{var8, player.getCommandSenderName()}), new Object[0]));
                     Hats.console(StatCollector.translateToLocalFormatted("hats.command.adminNotify.unlockHatForPlayer", new Object[]{icommandsender.getCommandSenderName(), var8, player.getCommandSenderName()}));
                     HatHandler.unlockHat(player, var8);
                  }
               } else {
                  icommandsender.addChatMessage(new ChatComponentTranslation("§7" + StatCollector.translateToLocal("hats.command.serverIsNotOnHatHuntingMode"), new Object[0]));
               }
            }
         }

      }
   }

   public List addTabCompletionOptions(ICommandSender par1ICommandSender, String[] args) {
      return args.length == 1?getListOfStringsMatchingLastWord(args, new String[]{"set", "send", "unlock"}):(args.length == 2?getListOfStringsMatchingLastWord(args, MinecraftServer.getServer().getAllUsernames()):(args.length == 3?getListOfStringsMatchingLastWord(args, HatHandler.getAllHatsAsArray()):null));
   }

   public String getUsageString() {
      return StatCollector.translateToLocal("hats.command") + " \n" + StatCollector.translateToLocal("hats.command.help.send") + " \n" + StatCollector.translateToLocal("hats.command.help.set") + " \n" + StatCollector.translateToLocal("hats.command.help.unlock");
   }
}

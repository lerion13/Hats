package hats.common.core;


public class TimeActiveInfo {

   public boolean active;
   public int timeLeft;
   public int levels;


   public void tick() {
      if(this.active && this.timeLeft > 0) {
         --this.timeLeft;
      }

   }
}

package hats.common.core;


public class HatInfo {

   public final String hatName;
   public final int colourR;
   public final int colourG;
   public final int colourB;
   public final int alpha;


   public HatInfo() {
      this.hatName = "";
      this.colourR = 0;
      this.colourG = 0;
      this.colourB = 0;
      this.alpha = 255;
   }

   public HatInfo(String name) {
      this.hatName = name;
      this.colourR = 255;
      this.colourG = 255;
      this.colourB = 255;
      this.alpha = 255;
   }

   public HatInfo(String name, int r, int g, int b, int alp) {
      this.hatName = name;
      this.colourR = r;
      this.colourG = g;
      this.colourB = b;
      this.alpha = alp;
   }
}

package hats.common.core;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import hats.api.RenderOnEntityHelper;
import hats.client.core.TickHandlerClient;
import hats.common.Hats;
import hats.common.core.CommonProxy;
import hats.common.core.HatInfo;
import hats.common.packet.PacketHatFragment;
import hats.common.packet.PacketPing;
import hats.common.packet.PacketRequestHat;
import hats.common.packet.PacketString;
import ichun.common.core.network.PacketHandler;
import ichun.common.core.techne.TC2Info;
import ichun.common.core.util.MD5Checksum;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import java.util.TreeMap;
import java.util.Map.Entry;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.MobSpawnerBaseLogic;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumChatFormatting;

public class HatHandler {

   public static boolean reloadingHats;
   public static File hatsFolder;
   public static HashMap queuedHats = new HashMap();
   public static HashMap hatParts = new HashMap();
   private static HashMap hatNames = new HashMap();
   public static HashMap checksums = new HashMap();
   public static HashMap categories = new HashMap();
   public static Random rand = new Random();
   public static Random hatGen = new Random();
   private static HashMap mobSpawners = new HashMap();
   private static HashMap mobSpawnerLogic = new HashMap();


   public static boolean isHatReadable(File file) {
      return file.getName().endsWith(".tc2")?TC2Info.readTechneFile(file) != null:false;
   }

   public static boolean readHatFromFile(File file) {
      return readHatFromFile(file, false);
   }

   public static boolean readHatFromFile(File file, boolean category) {
      String md5 = MD5Checksum.getMD5Checksum(file);
      if(checksums.get(md5) == null) {
         checksums.put(md5, file);
         if(file.getName().endsWith(".tc2")) {
            TC2Info info = TC2Info.readTechneFile(file);
            if(info == null) {
               Hats.console("Failed to load: " + file.getName() + " threw a generic exception! If no exception was printed, it\'s most likely the model has an invalid texture", true);
               return false;
            } else if(Hats.config.getInt("safeLoad") == 1 && info.tampered) {
               Hats.console("Rejecting " + file.getName() + "! It contains files which are not XML or PNG files!", true);
               return false;
            } else {
               Hats.proxy.loadHatFile(file);
               return true;
            }
         } else {
            return false;
         }
      } else if(!category) {
         Hats.console("Rejecting " + file.getName() + "! Identical to " + ((File)checksums.get(md5)).getName(), true);
         return true;
      } else {
         return false;
      }
   }

   public static int loadCategory(File dir) {
      int hatCount = 0;
      if(dir.isDirectory()) {
         ArrayList hatsToLoad = new ArrayList();
         ArrayList categoryHats = new ArrayList();
         File[] files = dir.listFiles();
         File[] arr$ = files;
         int len$ = files.length;

         for(int i$ = 0; i$ < len$; ++i$) {
            File file = arr$[i$];
            if(file.getName().endsWith(".tc2")) {
               String hatName = file.getName().substring(0, file.getName().length() - 4);
               hatsToLoad.add(hatName.toLowerCase());
               categoryHats.add(hatName);
               Iterator i$1 = getActualHatNamesMap().entrySet().iterator();

               while(i$1.hasNext()) {
                  Entry e = (Entry)i$1.next();
                  String hatEntryName = (String)e.getValue();

                  for(int i = hatsToLoad.size() - 1; i >= 0; --i) {
                     String hatCategoryEntryName = (String)hatsToLoad.get(i);
                     if(hatCategoryEntryName.equalsIgnoreCase(hatEntryName)) {
                        hatsToLoad.remove(i);
                        break;
                     }
                  }
               }

               if(!file.isDirectory() && readHatFromFile(file, true) && !dir.getName().equalsIgnoreCase("Favourites")) {
                  ++hatCount;
               }
            }
         }

         categories.put(dir.getName(), categoryHats);
      }

      return hatCount;
   }

   public static void deleteHat(String hatName, boolean disable) {
      deleteHat(hatsFolder, hatName, disable);
   }

   public static void deleteHat(File dir, String hatName, boolean disable) {
      File[] files = dir.listFiles();
      File[] arr$ = files;
      int len$ = files.length;

      int i$;
      File file;
      for(i$ = 0; i$ < len$; ++i$) {
         file = arr$[i$];
         if(!file.isDirectory() && file.getName().equalsIgnoreCase(hatName + ".tc2")) {
            if(disable) {
               File disabledDir = new File(dir, "/Disabled");
               if(!disabledDir.exists()) {
                  disabledDir.mkdirs();
               }

               File disabledName = new File(disabledDir, hatName + ".tc2");
               if(disabledName.exists()) {
                  disabledName.delete();
               }

               if(!file.renameTo(disabledName)) {
                  Hats.console("Failed to disable hat: " + file.getName());
               }
            } else if(!file.delete()) {
               Hats.console("Failed to delete hat: " + file.getName());
            }
            break;
         }
      }

      files = dir.listFiles();
      arr$ = files;
      len$ = files.length;

      for(i$ = 0; i$ < len$; ++i$) {
         file = arr$[i$];
         if(file.isDirectory() && !file.getName().equalsIgnoreCase("Disabled")) {
            deleteHat(file, hatName, disable);
         }
      }

   }

   public static boolean isInFavourites(String hatName) {
      return isInCategory(hatName, "Favourites");
   }

   public static boolean isInCategory(String hatName, String category) {
      if(category.equalsIgnoreCase("Contributors")) {
         return false;
      } else {
         ArrayList favs = (ArrayList)categories.get(category);
         if(favs != null) {
            Iterator i$ = favs.iterator();

            while(i$.hasNext()) {
               String s = (String)i$.next();
               if(s.equalsIgnoreCase(hatName)) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   public static boolean isContributor(String hatName) {
      ArrayList favs = (ArrayList)categories.get("Contributors");
      if(favs != null) {
         Iterator i$ = favs.iterator();

         while(i$.hasNext()) {
            String s = (String)i$.next();
            if(s.equalsIgnoreCase(hatName)) {
               return true;
            }
         }
      }

      return false;
   }

   public static void addToCategory(String hatName, String category) {
      ArrayList favs = (ArrayList)categories.get(category);
      if(favs != null) {
         boolean contained = false;

         for(int i$ = favs.size() - 1; i$ >= 0; --i$) {
            String e = (String)favs.get(i$);
            if(e.equalsIgnoreCase(hatName)) {
               contained = true;
               break;
            }
         }

         if(!contained) {
            Iterator var14 = getHatNames().entrySet().iterator();

            while(var14.hasNext()) {
               Entry var15 = (Entry)var14.next();
               if(hatName.toLowerCase().equalsIgnoreCase((String)var15.getValue())) {
                  File favFile = new File(hatsFolder, "/" + category + "/" + hatName + ".tc2");
                  FileInputStream inStream = null;
                  FileOutputStream outStream = null;

                  try {
                     inStream = new FileInputStream((File)var15.getKey());
                     outStream = new FileOutputStream(favFile);
                     byte[] e1 = new byte[1024];

                     int length;
                     while((length = inStream.read(e1)) > 0) {
                        outStream.write(e1, 0, length);
                     }
                  } catch (Exception var13) {
                     ;
                  }

                  try {
                     if(inStream != null) {
                        inStream.close();
                     }
                  } catch (IOException var12) {
                     ;
                  }

                  try {
                     if(outStream != null) {
                        outStream.close();
                     }
                  } catch (IOException var11) {
                     ;
                  }

                  favs.add(hatName);
                  break;
               }
            }
         }
      }

   }

   public static void removeFromCategory(String hatName, String category) {
      ArrayList favs = (ArrayList)categories.get(category);
      if(favs != null) {
         for(int i = favs.size() - 1; i >= 0; --i) {
            String fav = (String)favs.get(i);
            if(fav.equalsIgnoreCase(hatName)) {
               File favFile = new File(hatsFolder, "/" + category + "/" + hatName + ".tc2");
               File hatFile = new File(hatsFolder, hatName + ".tc2");
               if(!hatFile.exists()) {
                  favFile.renameTo(hatFile);
               } else {
                  favFile.delete();
               }

               favs.remove(i);
               break;
            }
         }
      }

   }

   public static void requestHat(String name, EntityPlayer player) {
      if(player != null) {
         PacketHandler.sendToPlayer(Hats.channels, new PacketRequestHat(name), player);
      } else {
         PacketHandler.sendToServer(Hats.channels, new PacketRequestHat(name));
      }

   }

   public static void receiveHatData(String hatName, byte packets, byte packetNumber, byte[] byteValues, EntityPlayer player, boolean isServer) {
      if(Hats.config.getInt("allowReceivingOfHats") == 1) {
         try {
            ArrayList e = (ArrayList)hatParts.get(hatName);
            if(e == null) {
               e = new ArrayList();
               hatParts.put(hatName, e);

               for(int hasAllInfo = 0; hasAllInfo < packets; ++hasAllInfo) {
                  e.add(new byte[0]);
               }
            }

            e.set(packetNumber, byteValues);
            boolean var17 = true;

            for(int file = 0; file < e.size(); ++file) {
               byte[] fis = (byte[])e.get(file);
               if(fis.length == 0) {
                  var17 = false;
               }
            }

            if(var17) {
               File var18 = new File(hatsFolder, hatName + ".tc2");
               if(var18.exists()) {
                  Hats.console(var18.getName() + " already exists! Will not save.");
                  return;
               }

               FileOutputStream var19 = new FileOutputStream(var18);

               for(int md5 = 0; md5 < e.size(); ++md5) {
                  byte[] newHat = (byte[])e.get(md5);
                  var19.write(newHat);
               }

               var19.close();
               String var21 = MD5Checksum.getMD5Checksum(var18);
               boolean var20 = checksums.get(var21) == null;
               if(readHatFromFile(var18)) {
                  CommonProxy var10000;
                  if(isServer) {
                     ArrayList queuedLists = (ArrayList)queuedHats.get(hatName.toLowerCase());
                     if(queuedLists != null) {
                        queuedHats.remove(hatName);
                        Iterator info = queuedLists.iterator();

                        while(info.hasNext()) {
                           String name = (String)info.next();
                           EntityPlayerMP player1 = FMLCommonHandler.instance().getMinecraftServerInstance().getConfigurationManager().func_152612_a(name);
                           if(player1 != null) {
                              sendHat(hatName, player1);
                           }
                        }
                     }

                     if(var20) {
                        Hats.console("Received " + var18.getName() + " from " + player.getCommandSenderName());
                     } else {
                        Hats.proxy.remap(var18.getName().substring(0, var18.getName().length() - 4).toLowerCase(), ((File)checksums.get(var21)).getName().substring(0, ((File)checksums.get(var21)).getName().length() - 4).toLowerCase());
                        Hats.console("Deleting " + var18.getName() + " from " + (isServer?player.getCommandSenderName():"server") + "! Duplicate hat file with different name. Remapping hat to original file.", true);
                        if(!var18.delete()) {
                           Hats.console("Failed to delete file! We\'re doomed!", true);
                        }

                        var10000 = Hats.proxy;
                        HatInfo var22 = (HatInfo)CommonProxy.playerWornHats.get(player.getCommandSenderName());
                        var10000 = Hats.proxy;
                        CommonProxy.playerWornHats.put(player.getCommandSenderName(), new HatInfo(((File)checksums.get(var21)).getName().substring(0, ((File)checksums.get(var21)).getName().length() - 4).toLowerCase(), var22.colourR, var22.colourG, var22.colourB, var22.alpha));
                     }

                     Hats.proxy.sendPlayerListOfWornHats(player, false);
                  } else {
                     var10000 = Hats.proxy;
                     CommonProxy.tickHandlerClient.requestedHats.remove(hatName.toLowerCase());
                     if(var20) {
                        Hats.console("Received " + var18.getName() + " from server.");
                        repopulateHatsList();
                     } else {
                        Hats.proxy.remap(var18.getName().substring(0, var18.getName().length() - 4).toLowerCase(), ((File)checksums.get(var21)).getName().substring(0, ((File)checksums.get(var21)).getName().length() - 4).toLowerCase());
                        Hats.console("Deleting " + var18.getName() + " from " + (isServer?player.getCommandSenderName():"server") + "! Duplicate hat file with different name. Remapping hat to original file.", true);
                        if(!var18.delete()) {
                           Hats.console("Failed to delete file! We\'re doomed!", true);
                        }
                     }
                  }
               } else {
                  Hats.console("Deleting " + var18.getName() + " from " + (isServer?player.getCommandSenderName():"server") + "! SafeLoad is on, and the Model file contains files which are not XML or PNG files.", true);
                  if(!var18.delete()) {
                     Hats.console("Failed to delete file! We\'re doomed!", true);
                  }
               }
            }
         } catch (IOException var16) {
            ;
         }

      }
   }

   public static void sendHat(String hatName, EntityPlayer player) {
      if(Hats.config.getInt("allowSendingOfHats") == 1) {
         File file = null;
         Iterator queuedLists = getHatNames().entrySet().iterator();

         while(queuedLists.hasNext()) {
            Entry e = (Entry)queuedLists.next();
            if(((String)e.getValue()).equalsIgnoreCase(hatName)) {
               file = (File)e.getKey();
            }
         }

         if(file != null) {
            int var10 = (int)file.length();
            if(var10 > 250000) {
               Hats.console("Unable to send " + file.getName() + ". It is above the size limit!", true);
               return;
            }

            if(var10 == 0) {
               Hats.console("Unable to send " + file.getName() + ". The file is empty!", true);
               return;
            }

            Hats.console("Sending " + file.getName() + " to " + (player == null?"the server":player.getCommandSenderName()));

            try {
               FileInputStream var12 = new FileInputStream(file);
               String hatFullName = file.getName().substring(0, file.getName().length() - 4);
               int packetsToSend = (int)Math.ceil((double)((float)var10 / 32000.0F));

               for(int packetCount = 0; var10 > 0; var10 -= 32000) {
                  byte[] fileBytes = new byte[var10 > 32000?32000:var10];
                  var12.read(fileBytes);
                  if(player != null) {
                     PacketHandler.sendToPlayer(Hats.channels, new PacketHatFragment(hatFullName, packetsToSend, packetCount, var10 > 32000?32000:var10, fileBytes), player);
                  } else {
                     PacketHandler.sendToServer(Hats.channels, new PacketHatFragment(hatFullName, packetsToSend, packetCount, var10 > 32000?32000:var10, fileBytes));
                  }

                  ++packetCount;
               }

               var12.close();
            } catch (IOException var9) {
               ;
            }
         } else if(player != null) {
            ArrayList var11 = (ArrayList)queuedHats.get(hatName.toLowerCase());
            if(var11 == null) {
               var11 = new ArrayList();
               queuedHats.put(hatName, var11);
            }

            var11.add(player.getCommandSenderName());
         }

      }
   }

   public static boolean hasHat(String name) {
      if(name.equalsIgnoreCase("")) {
         return true;
      } else {
         Iterator i$ = getHatNames().entrySet().iterator();

         Entry e;
         do {
            if(!i$.hasNext()) {
               return false;
            }

            e = (Entry)i$.next();
         } while(!((String)e.getValue()).equalsIgnoreCase(name));

         return true;
      }
   }

   public static String getHatStartingWith(String name) {
      Iterator i$ = getHatNames().entrySet().iterator();

      Entry e;
      do {
         if(!i$.hasNext()) {
            return name;
         }

         e = (Entry)i$.next();
      } while(!((String)e.getValue()).toLowerCase().startsWith(name.toLowerCase()));

      return (String)e.getValue();
   }

   public static ArrayList getAllHats() {
      ArrayList hatList = new ArrayList();
      Iterator ite = getHatNames().entrySet().iterator();

      while(ite.hasNext()) {
         Entry e = (Entry)ite.next();
         hatList.add(e.getValue());
      }

      return hatList;
   }

   public static ArrayList getHatsWithWeightedContributors() {
      ArrayList hatList = new ArrayList();
      Iterator ite = getHatNames().entrySet().iterator();

      while(ite.hasNext()) {
         Entry e = (Entry)ite.next();
         if(!((String)e.getValue()).startsWith("(C)".toLowerCase()) || rand.nextFloat() <= (float)Hats.config.getInt("useRandomContributorHats") / 100.0F) {
            hatList.add(e.getValue());
         }
      }

      return hatList;
   }

   public static EnumChatFormatting getHatRarityColour(String hat) {
      if(Hats.config.getSessionInt("hatGenerationSeed") == 0) {
         return EnumChatFormatting.WHITE;
      } else {
         float rarity = getHatRarity(hat);
         return rarity < 0.14285715F?EnumChatFormatting.AQUA:(rarity < 0.2857143F?EnumChatFormatting.GOLD:(rarity < 0.42857143F?EnumChatFormatting.YELLOW:(rarity < 0.5714286F?EnumChatFormatting.LIGHT_PURPLE:(rarity < 0.71428573F?EnumChatFormatting.BLUE:(rarity < 0.85714287F?EnumChatFormatting.DARK_GREEN:(rarity < 1.0F?EnumChatFormatting.WHITE:EnumChatFormatting.WHITE))))));
      }
   }

   public static float getHatRarity(String hatName) {
      hatGen.setSeed((long)Hats.config.getSessionInt("hatGenerationSeed"));
      int hash = Math.abs(hatName.toLowerCase().hashCode());
      int rand = hatGen.nextInt(hash);
      return (float)rand / (float)hash;
   }

   public static HatInfo getRandomHatFromList(ArrayList list, boolean withRarity) {
      if(list.size() == 1) {
         return new HatInfo((String)list.get(0), 255, 255, 255, 255);
      } else if(list.size() == 0) {
         return new HatInfo();
      } else if(withRarity) {
         HatInfo hat = null;
         boolean triesPerPass = true;
         float randAmp = 1.0F;
         int tries = 0;

         while(hat == null) {
            String hatName = (String)list.get(rand.nextInt(list.size()));
            float rarity = getHatRarity(hatName);
            if(rand.nextFloat() < rarity * randAmp) {
               hat = new HatInfo(hatName, 255, 255, 255, 255);
            }

            ++tries;
            if(tries >= 500) {
               tries = 0;
               randAmp += 0.05F;
            }
         }

         return hat;
      } else {
         return new HatInfo((String)list.get(rand.nextInt(list.size())), 255, 255, 255, 255);
      }
   }

   public static ArrayList getAllHatNamesAsList() {
      ArrayList hatNameList = new ArrayList();
      Iterator ite = getHatNames().entrySet().iterator();

      while(ite.hasNext()) {
         Entry e = (Entry)ite.next();
         String name = ((File)e.getKey()).getName().substring(0, ((File)e.getKey()).getName().length() - 4);
         hatNameList.add(name);
      }

      Collections.sort(hatNameList);
      return hatNameList;
   }

   public static String[] getAllHatsAsArray() {
      ArrayList hatNameList = getAllHatNamesAsList();
      String[] hatNameArray = new String[hatNameList.size()];
      hatNameList.toArray(hatNameArray);
      return hatNameArray;
   }

   public static void unlockHat(EntityPlayer player, String hat) {
      if(player != null && hat != null && !hat.isEmpty()) {
         CommonProxy var10000 = Hats.proxy;
         TreeMap hats = CommonProxy.tickHandlerServer.getPlayerHatsList(player.getCommandSenderName());
         Iterator ite = getHatNames().entrySet().iterator();

         while(ite.hasNext()) {
            Entry e = (Entry)ite.next();
            String name = ((File)e.getKey()).getName().substring(0, ((File)e.getKey()).getName().length() - 4);
            if(name.equalsIgnoreCase(hat)) {
               Integer hatCount = (Integer)hats.get(name);
               if(hatCount == null) {
                  hatCount = Integer.valueOf(1);
                  hats.put(name, hatCount);
               } else {
                  hats.put(name, Integer.valueOf(hatCount.intValue() + 1));
               }

               StringBuilder sb = new StringBuilder();

               for(Iterator persistentTag = hats.entrySet().iterator(); persistentTag.hasNext(); sb.append(":")) {
                  Entry e1 = (Entry)persistentTag.next();
                  String hatName = getNameForHat((String)e1.getKey());
                  sb.append(hatName);
                  if(((Integer)e1.getValue()).intValue() > 1) {
                     sb.append(">" + e1.getValue());
                  }
               }

               NBTTagCompound persistentTag1 = player.getEntityData().getCompoundTag("PlayerPersisted");
               persistentTag1.setString("Hats_unlocked", sb.toString().length() > 0?sb.toString().substring(0, sb.toString().length() - 1):sb.toString());
               player.getEntityData().setTag("PlayerPersisted", persistentTag1);
               PacketHandler.sendToPlayer(Hats.channels, new PacketString(0, name), player);
               break;
            }
         }

      }
   }

   public static String getNameForHat(String hat) {
      Iterator i$ = getHatNames().entrySet().iterator();

      Entry e2;
      do {
         if(!i$.hasNext()) {
            return hat;
         }

         e2 = (Entry)i$.next();
      } while(!((String)e2.getValue()).equalsIgnoreCase(hat));

      return ((File)e2.getKey()).getName().substring(0, ((File)e2.getKey()).getName().length() - 4);
   }

   @SideOnly(Side.CLIENT)
   public static void reloadAndOpenGui() {
      repopulateHatsList();
      if(Hats.config.getSessionInt("playerHatsMode") == 3) {
         PacketHandler.sendToServer(Hats.channels, new PacketPing(0, false));
      } else if(Hats.config.getSessionInt("playerHatsMode") != 2) {
         Hats.proxy.openHatsGui();
      }

   }

   @SideOnly(Side.CLIENT)
   public static void repopulateHatsList() {
      CommonProxy var10000 = Hats.proxy;
      CommonProxy.tickHandlerClient.availableHats.clear();
      Iterator ite = getHatNames().entrySet().iterator();

      while(ite.hasNext()) {
         Entry e = (Entry)ite.next();
         var10000 = Hats.proxy;
         CommonProxy.tickHandlerClient.availableHats.put(((File)e.getKey()).getName().substring(0, ((File)e.getKey()).getName().length() - 4), Integer.valueOf(1));
      }

   }

   @SideOnly(Side.CLIENT)
   public static void populateHatsList(String s) {
      CommonProxy var10000 = Hats.proxy;
      CommonProxy.tickHandlerClient.availableHats.clear();
      String[] split = s.split(":");
      String[] ite = split;
      int e = split.length;

      for(int name = 0; name < e; ++name) {
         String hatNameWithCount = ite[name];
         String[] hatNameAndCount = hatNameWithCount.split(">");
         if(!hatNameAndCount[0].trim().isEmpty()) {
            try {
               var10000 = Hats.proxy;
               CommonProxy.tickHandlerClient.availableHats.put(hatNameAndCount[0].trim(), Integer.valueOf(hatNameAndCount.length == 1?1:Integer.parseInt(hatNameAndCount[1])));
            } catch (Exception var8) {
               var10000 = Hats.proxy;
               CommonProxy.tickHandlerClient.availableHats.put(hatNameAndCount[0].trim(), Integer.valueOf(1));
            }
         }
      }

      Iterator var10 = getHatNames().entrySet().iterator();

      while(var10.hasNext()) {
         Entry var12 = (Entry)var10.next();
         String var14 = ((File)var12.getKey()).getName().substring(0, ((File)var12.getKey()).getName().length() - 4);
         if(isPlayersContributorHat(var14, Minecraft.getMinecraft().thePlayer.getCommandSenderName())) {
            var10000 = Hats.proxy;
            HashMap var13 = CommonProxy.tickHandlerClient.availableHats;
            CommonProxy var10002 = Hats.proxy;
            int var9;
            if(CommonProxy.tickHandlerClient.availableHats.get(var14) == null) {
               var9 = 1;
            } else {
               var10002 = Hats.proxy;
               var9 = ((Integer)CommonProxy.tickHandlerClient.availableHats.get(var14)).intValue() + 1;
            }

            var13.put(var14, Integer.valueOf(var9));
         }
      }

      var10000 = Hats.proxy;
      TickHandlerClient var11 = CommonProxy.tickHandlerClient;
      HashMap var10001 = new HashMap(CommonProxy.tickHandlerClient.availableHats);
      CommonProxy var10003 = Hats.proxy;
      var11.serverHats = var10001;
   }

   public static boolean isPlayersContributorHat(String hatName, String playerName) {
      return hatName.toLowerCase().startsWith("(c)") && hatName.toLowerCase().contains(playerName.toLowerCase()) || hatName.equalsIgnoreCase("(C) iChun") && playerName.equalsIgnoreCase("ohaiiChun") || hatName.equalsIgnoreCase("(C) Mr. Haz") && playerName.equalsIgnoreCase("damien95") || hatName.equalsIgnoreCase("(C) Fridgeboy") && playerName.equalsIgnoreCase("lacsap32");
   }

   public static boolean canMobHat(EntityLivingBase ent) {
      return !ent.isDead && !ent.isChild() && getRenderHelper(ent.getClass()) != null && getRenderHelper(ent.getClass()).canWearHat(ent);
   }

   public static RenderOnEntityHelper getRenderHelper(Class clz) {
      if(EntityLivingBase.class.isAssignableFrom(clz) && clz != EntityLivingBase.class) {
         RenderOnEntityHelper helper = (RenderOnEntityHelper)CommonProxy.renderHelpers.get(clz);
         return helper == null?getRenderHelper(clz.getSuperclass()):helper;
      } else {
         return null;
      }
   }

   public static boolean isMobSpawner(Class clz, Class callingClz) {
      if(!TileEntity.class.isAssignableFrom(clz)) {
         return false;
      } else {
         Boolean bool = (Boolean)mobSpawners.get(clz);
         if(bool == null) {
            try {
               Field[] e = clz.getDeclaredFields();
               Field[] arr$ = e;
               int len$ = e.length;

               for(int i$ = 0; i$ < len$; ++i$) {
                  Field field = arr$[i$];
                  field.setAccessible(true);
                  if(MobSpawnerBaseLogic.class.isAssignableFrom(field.getType())) {
                     bool = Boolean.valueOf(true);
                     mobSpawnerLogic.put(callingClz, field);
                     mobSpawners.put(callingClz, bool);
                     break;
                  }
               }

               if(bool == null) {
                  bool = Boolean.valueOf(clz.getSuperclass() == TileEntity.class?false:isMobSpawner(clz.getSuperclass(), callingClz));
                  mobSpawners.put(callingClz, bool);
               }
            } catch (Throwable var8) {
               bool = Boolean.valueOf(false);
               mobSpawners.put(callingClz, bool);
            }
         }

         return bool.booleanValue();
      }
   }

   public static MobSpawnerBaseLogic getMobSpawnerLogic(Class clz, TileEntity instance) {
      try {
         Field e = (Field)mobSpawnerLogic.get(clz);
         if(e != null) {
            e.setAccessible(true);
            Object obj = e.get(instance);
            if(obj instanceof MobSpawnerBaseLogic) {
               return (MobSpawnerBaseLogic)obj;
            }
         }
      } catch (Exception var4) {
         ;
      }

      return null;
   }

   public static HashMap getHatNames() {
      return reloadingHats?new HashMap():hatNames;
   }

   public static HashMap getActualHatNamesMap() {
      return hatNames;
   }

}

package hats.common.core;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.eventhandler.EventPriority;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent;
import cpw.mods.fml.common.gameevent.PlayerEvent.PlayerLoggedOutEvent;
import cpw.mods.fml.common.network.FMLNetworkEvent.ClientConnectedToServerEvent;
import cpw.mods.fml.common.network.FMLNetworkEvent.ClientDisconnectionFromServerEvent;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import hats.common.Hats;
import hats.common.core.CommonProxy;
import hats.common.core.HatHandler;
import hats.common.core.HatInfo;
import hats.common.core.TimeActiveInfo;
import hats.common.packet.PacketPing;
import hats.common.packet.PacketSession;
import ichun.client.keybind.KeyEvent;
import ichun.common.core.network.PacketHandler;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;
import java.util.Map.Entry;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.MobSpawnerBaseLogic;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;

public class EventHandler {

   @SideOnly(Side.CLIENT)
   @SubscribeEvent
   public void onKeyEvent(KeyEvent event) {
      Minecraft mc = Minecraft.getMinecraft();
      if(event.keyBind.isPressed() && event.keyBind == Hats.config.getKeyBind("guiKeyBind") && mc.currentScreen == null) {
         CommonProxy var10000 = Hats.proxy;
         if(!CommonProxy.tickHandlerClient.hasScreen) {
            if(Hats.config.getSessionInt("playerHatsMode") == 3) {
               PacketHandler.sendToServer(Hats.channels, new PacketPing(0, false));
            } else if(Hats.config.getSessionInt("playerHatsMode") == 2) {
               mc.thePlayer.addChatMessage(new ChatComponentTranslation("hats.lockedMode", new Object[0]));
            } else if(Hats.config.getSessionInt("playerHatsMode") == 5 && !Hats.config.getSessionString("currentKing").equalsIgnoreCase(mc.thePlayer.getCommandSenderName())) {
               mc.thePlayer.addChatMessage(new ChatComponentTranslation("hats.kingOfTheHat.notKing", new Object[]{Hats.config.getSessionString("currentKing")}));
            } else {
               Hats.proxy.openHatsGui();
            }
         }
      }

   }

   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public void onEntitySpawn(EntityJoinWorldEvent event) {
      if(!FMLCommonHandler.instance().getEffectiveSide().isClient() && event.entity instanceof EntityLivingBase && HatHandler.canMobHat((EntityLivingBase)event.entity)) {
         CommonProxy var10000 = Hats.proxy;
         if(!CommonProxy.tickHandlerServer.mobHats.containsKey(event.entity)) {
            EntityLivingBase living = (EntityLivingBase)event.entity;
            boolean fromSpawner = false;

            for(int hatInfo = 0; hatInfo < event.entity.worldObj.loadedTileEntityList.size(); ++hatInfo) {
               TileEntity te = (TileEntity)event.entity.worldObj.loadedTileEntityList.get(hatInfo);
               if(HatHandler.isMobSpawner(te.getClass(), te.getClass())) {
                  MobSpawnerBaseLogic logic = HatHandler.getMobSpawnerLogic(te.getClass(), te);
                  if(logic.isActivated()) {
                     Entity entity = EntityList.createEntityByName(logic.getEntityNameToSpawn(), logic.getSpawnerWorld());
                     if(entity != null && living.getClass() == entity.getClass()) {
                        List list = logic.getSpawnerWorld().getEntitiesWithinAABB(entity.getClass(), AxisAlignedBB.getBoundingBox((double)logic.getSpawnerX(), (double)logic.getSpawnerY(), (double)logic.getSpawnerZ(), (double)(logic.getSpawnerX() + 1), (double)(logic.getSpawnerY() + 1), (double)(logic.getSpawnerZ() + 1)).expand(8.0D, 4.0D, 8.0D));
                        if(list.contains(living)) {
                           fromSpawner = true;
                           break;
                        }
                     }
                  }
               }
            }

            HatInfo var9;
            if(living.getEntityData().hasKey("Hats_hatInfo")) {
               var9 = new HatInfo(living.getEntityData().getString("Hats_hatInfo"));
            } else {
               var9 = living.getRNG().nextFloat() < (float)Hats.config.getInt("randomMobHat") / 100.0F && !fromSpawner?HatHandler.getRandomHatFromList(HatHandler.getHatsWithWeightedContributors(), Hats.config.getSessionInt("playerHatsMode") == 4 && Hats.config.getInt("hatRarity") == 1):new HatInfo();
               living.getEntityData().setString("Hats_hatInfo", var9.hatName);
            }

            if(!var9.hatName.isEmpty()) {
               var10000 = Hats.proxy;
               CommonProxy.tickHandlerServer.mobHats.put(living, var9.hatName);
            }

            return;
         }
      }

   }

   @SubscribeEvent
   public void onLivingDeath(LivingDeathEvent event) {
      if(FMLCommonHandler.instance().getEffectiveSide() == Side.SERVER) {
         CommonProxy var10000;
         if(Hats.config.getSessionInt("playerHatsMode") >= 4) {
            if(Hats.config.getSessionInt("playerHatsMode") == 4 && !(event.entityLiving instanceof EntityPlayer) && event.source.getEntity() instanceof EntityPlayer && !((EntityPlayer)event.source.getEntity()).capabilities.isCreativeMode) {
               var10000 = Hats.proxy;
               CommonProxy.tickHandlerServer.playerKilledEntity(event.entityLiving, (EntityPlayer)event.source.getEntity());
            }

            if(event.entityLiving instanceof EntityPlayer) {
               EntityPlayer player = (EntityPlayer)event.entityLiving;
               EntityPlayer executer = null;
               if(event.source.getEntity() instanceof EntityPlayer) {
                  executer = (EntityPlayer)event.source.getEntity();
               }

               if(Hats.config.getSessionInt("playerHatsMode") == 5) {
                  ArrayList newHats;
                  if(Hats.config.getSessionString("currentKing").equalsIgnoreCase(player.getCommandSenderName())) {
                     if(executer != null) {
                        var10000 = Hats.proxy;
                        CommonProxy.tickHandlerServer.updateNewKing(executer.getCommandSenderName(), (EntityPlayer)null, true);
                        var10000 = Hats.proxy;
                        CommonProxy.tickHandlerServer.updateNewKing(executer.getCommandSenderName(), executer, true);
                        FMLCommonHandler.instance().getMinecraftServerInstance().getConfigurationManager().sendChatMsg(new ChatComponentTranslation("hats.kingOfTheHat.update.playerSlayed", new Object[]{player.getCommandSenderName(), executer.getCommandSenderName()}));
                     } else {
                        List playerHatsList = FMLCommonHandler.instance().getMinecraftServerInstance().getConfigurationManager().playerEntityList;
                        newHats = new ArrayList(playerHatsList);
                        newHats.remove(player);
                        if(!newHats.isEmpty()) {
                           EntityPlayer newKingEnt = (EntityPlayer)newHats.get(player.worldObj.rand.nextInt(newHats.size()));
                           var10000 = Hats.proxy;
                           CommonProxy.tickHandlerServer.updateNewKing(newKingEnt.getCommandSenderName(), (EntityPlayer)null, true);
                           var10000 = Hats.proxy;
                           CommonProxy.tickHandlerServer.updateNewKing(newKingEnt.getCommandSenderName(), newKingEnt, true);
                           FMLCommonHandler.instance().getMinecraftServerInstance().getConfigurationManager().sendChatMsg(new ChatComponentTranslation("hats.kingOfTheHat.update.playerDied", new Object[]{player.getCommandSenderName(), newKingEnt.getCommandSenderName()}));
                        }
                     }
                  } else if(executer != null && Hats.config.getSessionString("currentKing").equalsIgnoreCase(executer.getCommandSenderName())) {
                     var10000 = Hats.proxy;
                     TreeMap playerHatsList1 = CommonProxy.tickHandlerServer.getPlayerHatsList(executer.getCommandSenderName());
                     newHats = HatHandler.getAllHatNamesAsList();
                     Iterator newKingEnt2 = playerHatsList1.entrySet().iterator();

                     while(newKingEnt2.hasNext()) {
                        Entry e = (Entry)newKingEnt2.next();
                        newHats.remove(e.getKey());
                     }

                     EntityPlayerMP newKingEnt1 = FMLCommonHandler.instance().getMinecraftServerInstance().getConfigurationManager().func_152612_a(executer.getCommandSenderName());
                     if(newKingEnt1 != null && !newHats.isEmpty()) {
                        HatHandler.unlockHat(newKingEnt1, (String)newHats.get(newKingEnt1.worldObj.rand.nextInt(newHats.size())));
                     }
                  }
               }

               if(Hats.config.getInt("resetPlayerHatsOnDeath") == 1) {
                  var10000 = Hats.proxy;
                  CommonProxy.tickHandlerServer.playerDeath((EntityPlayer)event.entityLiving);
               }
            }
         }

         var10000 = Hats.proxy;
         CommonProxy.tickHandlerServer.mobHats.remove(event.entityLiving);
      }

   }

   @SubscribeEvent
   public void onClientConnect(ClientConnectedToServerEvent event) {
      CommonProxy var10000 = Hats.proxy;
      CommonProxy.tickHandlerClient.isActive = true;
      Hats.config.resetSession();
      Hats.config.updateSession("serverHasMod", Integer.valueOf(0));
      Hats.config.updateSession("playerHatsMode", Integer.valueOf(1));
      Hats.config.updateSession("hasVisited", Integer.valueOf(1));
      Hats.config.updateSession("lockedHat", "");
      Hats.config.updateSession("currentKing", "");
      Hats.config.updateSession("showJoinMessage", Integer.valueOf(0));
      HatHandler.repopulateHatsList();
   }

   @SubscribeEvent
   public void onClientDisconnect(ClientDisconnectionFromServerEvent event) {
      CommonProxy var10000 = Hats.proxy;
      CommonProxy.tickHandlerClient.hats.clear();
      var10000 = Hats.proxy;
      CommonProxy.tickHandlerClient.mobHats.clear();
      var10000 = Hats.proxy;
      CommonProxy.tickHandlerClient.playerWornHats.clear();
      var10000 = Hats.proxy;
      CommonProxy.tickHandlerClient.requestedHats.clear();
      var10000 = Hats.proxy;
      if(CommonProxy.tickHandlerClient.guiHatUnlocked != null) {
         var10000 = Hats.proxy;
         CommonProxy.tickHandlerClient.guiHatUnlocked.hatList.clear();
      }

      var10000 = Hats.proxy;
      if(CommonProxy.tickHandlerClient.guiNewTradeReq != null) {
         var10000 = Hats.proxy;
         CommonProxy.tickHandlerClient.guiNewTradeReq.hatList.clear();
      }

      var10000 = Hats.proxy;
      CommonProxy.tickHandlerClient.worldInstance = null;
   }

   public static void sendPlayerSessionInfo(EntityPlayer player) {
      CommonProxy var10000 = Hats.proxy;
      TreeMap playerHatsList = CommonProxy.tickHandlerServer.getPlayerHatsList(player.getCommandSenderName());
      StringBuilder sb = new StringBuilder();

      for(Iterator i$ = playerHatsList.entrySet().iterator(); i$.hasNext(); sb.append(":")) {
         Entry e = (Entry)i$.next();
         sb.append((String)e.getKey());
         if(((Integer)e.getValue()).intValue() != 1) {
            sb.append(">" + e.getValue());
         }
      }

      PacketHandler.sendToPlayer(Hats.channels, new PacketSession(Hats.config.getSessionInt("playerHatsMode"), Hats.config.getInt("hatRarity") == 0?0:Hats.config.getSessionInt("hatGenerationSeed"), player.getEntityData().getCompoundTag("PlayerPersisted").getBoolean("Hats_hasVisited") && player.getEntityData().getCompoundTag("PlayerPersisted").getInteger("Hats_hatMode") == Hats.config.getSessionInt("playerHatsMode") || Hats.config.getInt("firstJoinMessage") != 1, Hats.config.getSessionString("lockedHat"), Hats.config.getSessionString("currentKing"), sb.toString().length() > 0?sb.toString().substring(0, sb.toString().length() - 1):sb.toString()), player);
   }

   @SubscribeEvent
   public void onPlayerLogin(PlayerLoggedInEvent event) {
      CommonProxy var10000;
      if(Hats.config.getSessionInt("playerHatsMode") == 5 && Hats.config.getSessionString("currentKing").equalsIgnoreCase("")) {
         var10000 = Hats.proxy;
         CommonProxy.tickHandlerServer.updateNewKing(event.player.getCommandSenderName(), (EntityPlayer)null, false);
         FMLCommonHandler.instance().getMinecraftServerInstance().getConfigurationManager().sendChatMsg(new ChatComponentTranslation("hats.kingOfTheHat.update.playerJoin", new Object[]{event.player.getCommandSenderName()}));
      }

      String playerHats = event.player.getEntityData().getCompoundTag("PlayerPersisted").getString("Hats_unlocked");
      if(Hats.config.getSessionInt("playerHatsMode") == 5 && !Hats.config.getSessionString("currentKing").equalsIgnoreCase(event.player.getCommandSenderName())) {
         playerHats = "";
         NBTTagCompound playerHatsList = event.player.getEntityData().getCompoundTag("PlayerPersisted");
         playerHatsList.setString("Hats_unlocked", playerHats);
         playerHatsList.setString("Hats_wornHat", "");
         event.player.getEntityData().setTag("PlayerPersisted", playerHatsList);
      }

      var10000 = Hats.proxy;
      TreeMap var12 = CommonProxy.tickHandlerServer.getPlayerHatsList(event.player.getCommandSenderName());
      var12.clear();
      String[] hatsWithCount = playerHats.split(":");
      String[] hatName = hatsWithCount;
      int r = hatsWithCount.length;

      int g;
      for(g = 0; g < r; ++g) {
         String b = hatName[g];
         String[] a = b.split(">");
         if(!a[0].trim().isEmpty()) {
            try {
               var12.put(a[0], Integer.valueOf(a.length == 1?1:Integer.parseInt(a[1])));
            } catch (NumberFormatException var11) {
               var12.put(a[0], Integer.valueOf(1));
            }
         }
      }

      String var13 = event.player.getEntityData().getCompoundTag("PlayerPersisted").getString("Hats_wornHat");
      r = event.player.getEntityData().getCompoundTag("PlayerPersisted").getInteger("Hats_colourR");
      g = event.player.getEntityData().getCompoundTag("PlayerPersisted").getInteger("Hats_colourG");
      int var14 = event.player.getEntityData().getCompoundTag("PlayerPersisted").getInteger("Hats_colourB");
      int var15 = event.player.getEntityData().getCompoundTag("PlayerPersisted").getInteger("Hats_alpha");
      if(var15 == 0) {
         event.player.getEntityData().getCompoundTag("PlayerPersisted").setInteger("Hats_alpha", 255);
         var15 = 255;
      }

      if(!HatHandler.hasHat(var13)) {
         HatHandler.requestHat(var13, event.player);
      }

      var10000 = Hats.proxy;
      CommonProxy.playerWornHats.put(event.player.getCommandSenderName(), new HatInfo(var13, r, g, var14, var15));
      if(Hats.config.getSessionInt("playerHatsMode") == 6) {
         var10000 = Hats.proxy;
         TimeActiveInfo persistentTag = (TimeActiveInfo)CommonProxy.tickHandlerServer.playerActivity.get(event.player.getCommandSenderName());
         if(persistentTag == null) {
            persistentTag = new TimeActiveInfo();
            persistentTag.timeLeft = event.player.getEntityData().getCompoundTag("PlayerPersisted").getInteger("Hats_activityTimeleft");
            persistentTag.levels = event.player.getEntityData().getCompoundTag("PlayerPersisted").getInteger("Hats_activityLevels");
            if(persistentTag.levels == 0 && persistentTag.timeLeft == 0) {
               persistentTag.levels = 0;
               persistentTag.timeLeft = Hats.config.getInt("startTime");
            }

            var10000 = Hats.proxy;
            CommonProxy.tickHandlerServer.playerActivity.put(event.player.getCommandSenderName(), persistentTag);
         }

         persistentTag.active = true;
      }

      sendPlayerSessionInfo(event.player);
      NBTTagCompound var16 = event.player.getEntityData().getCompoundTag("PlayerPersisted");
      var16.setBoolean("Hats_hasVisited", true);
      var16.setInteger("Hats_hatMode", Hats.config.getSessionInt("playerHatsMode"));
      event.player.getEntityData().setTag("PlayerPersisted", var16);
      if(Hats.config.getSessionInt("playerHatsMode") != 2) {
         Hats.proxy.sendPlayerListOfWornHats(event.player, true);
         Hats.proxy.sendPlayerListOfWornHats(event.player, false);
      }

   }

   @SubscribeEvent
   public void onPlayerLogout(PlayerLoggedOutEvent event) {
      CommonProxy var10000;
      if(Hats.config.getSessionInt("playerHatsMode") == 5 && Hats.config.getSessionString("currentKing").equalsIgnoreCase(event.player.getCommandSenderName())) {
         List info = FMLCommonHandler.instance().getMinecraftServerInstance().getConfigurationManager().playerEntityList;
         ArrayList persistentTag = new ArrayList(info);
         persistentTag.remove(event.player);
         if(!persistentTag.isEmpty()) {
            EntityPlayer newKing = (EntityPlayer)persistentTag.get(event.player.worldObj.rand.nextInt(persistentTag.size()));
            var10000 = Hats.proxy;
            CommonProxy.tickHandlerServer.updateNewKing(newKing.getCommandSenderName(), (EntityPlayer)null, true);
            var10000 = Hats.proxy;
            CommonProxy.tickHandlerServer.updateNewKing(newKing.getCommandSenderName(), newKing, true);
            FMLCommonHandler.instance().getMinecraftServerInstance().getConfigurationManager().sendChatMsg(new ChatComponentTranslation("hats.kingOfTheHat.update.playerLeft", new Object[]{event.player.getCommandSenderName(), newKing.getCommandSenderName()}));
         }
      }

      var10000 = Hats.proxy;
      TimeActiveInfo info1 = (TimeActiveInfo)CommonProxy.tickHandlerServer.playerActivity.get(event.player.getCommandSenderName());
      if(info1 != null) {
         NBTTagCompound persistentTag1 = event.player.getEntityData().getCompoundTag("PlayerPersisted");
         persistentTag1.setInteger("Hats_activityLevels", info1.levels);
         persistentTag1.setInteger("Hats_activityTimeleft", info1.timeLeft);
         event.player.getEntityData().setTag("PlayerPersisted", persistentTag1);
         info1.active = false;
      }

      var10000 = Hats.proxy;
      CommonProxy.playerWornHats.remove(event.player.getCommandSenderName());
   }
}

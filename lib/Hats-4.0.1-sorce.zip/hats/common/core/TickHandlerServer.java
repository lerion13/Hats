package hats.common.core;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent.Phase;
import cpw.mods.fml.common.gameevent.TickEvent.ServerTickEvent;
import hats.api.RenderOnEntityHelper;
import hats.common.Hats;
import hats.common.core.CommonProxy;
import hats.common.core.EventHandler;
import hats.common.core.HatHandler;
import hats.common.core.HatInfo;
import hats.common.core.TimeActiveInfo;
import hats.common.packet.PacketKingOfTheHatInfo;
import hats.common.packet.PacketPing;
import hats.common.trade.TradeInfo;
import hats.common.trade.TradeRequest;
import ichun.common.core.network.PacketHandler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.WeakHashMap;
import java.util.Map.Entry;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;

public class TickHandlerServer {

   public WeakHashMap mobHats = new WeakHashMap();
   public HashMap playerHats = new HashMap();
   public HashMap playerActivity = new HashMap();
   public HashMap playerTradeRequests = new HashMap();
   public ArrayList activeTrades = new ArrayList();


   @SubscribeEvent
   public void serverTick(ServerTickEvent event) {
      if(event.phase == Phase.START) {
         Iterator iterator1 = this.mobHats.entrySet().iterator();

         while(iterator1.hasNext()) {
            Entry ite = (Entry)iterator1.next();
            if(((EntityLivingBase)ite.getKey()).isDead) {
               iterator1.remove();
            }
         }

         Iterator var14 = this.playerActivity.entrySet().iterator();

         Entry i;
         TreeMap trader1Hats;
         CommonProxy var10000;
         while(var14.hasNext()) {
            i = (Entry)var14.next();
            TimeActiveInfo ti = (TimeActiveInfo)i.getValue();
            ti.tick();
            if(ti.timeLeft == 0 && ti.active) {
               ++ti.levels;
               ti.timeLeft = Hats.config.getInt("startTime");
               var10000 = Hats.proxy;
               trader1Hats = CommonProxy.tickHandlerServer.getPlayerHatsList((String)i.getKey());
               ArrayList trader2Hats = HatHandler.getAllHatNamesAsList();
               Iterator sb = trader1Hats.entrySet().iterator();

               while(sb.hasNext()) {
                  Entry persistentTag = (Entry)sb.next();
                  trader2Hats.remove(persistentTag.getKey());
               }

               EntityPlayerMP var20 = FMLCommonHandler.instance().getMinecraftServerInstance().getConfigurationManager().func_152612_a((String)i.getKey());
               if(var20 != null && !trader2Hats.isEmpty()) {
                  HatHandler.unlockHat(var20, HatHandler.getRandomHatFromList(trader2Hats, Hats.config.getInt("hatRarity") == 1).hatName);
               }

               for(int var21 = 0; var21 < ti.levels; ++var21) {
                  ti.timeLeft = (int)((float)ti.timeLeft * (1.0F + (float)Hats.config.getInt("timeIncrement") / 10000.0F));
               }
            }
         }

         var14 = this.playerTradeRequests.entrySet().iterator();

         while(var14.hasNext()) {
            i = (Entry)var14.next();
            TradeRequest var16 = (TradeRequest)i.getValue();
            ++var16.timePending;
            if(var16.timePending >= 1200) {
               var14.remove();
            }
         }

         for(int var15 = this.activeTrades.size() - 1; var15 >= 0; --var15) {
            TradeInfo var17 = (TradeInfo)this.activeTrades.get(var15);
            var17.update();
            if(var17.trade1 && var17.trade2) {
               var10000 = Hats.proxy;
               trader1Hats = CommonProxy.tickHandlerServer.getPlayerHatsList(var17.trader1.getCommandSenderName());
               var10000 = Hats.proxy;
               TreeMap var18 = CommonProxy.tickHandlerServer.getPlayerHatsList(var17.trader2.getCommandSenderName());
               this.transferHat(trader1Hats, var18, var17.trader1Hats);
               this.transferHat(var18, trader1Hats, var17.trader2Hats);
               StringBuilder var19 = new StringBuilder();

               for(Iterator var22 = trader1Hats.entrySet().iterator(); var22.hasNext(); var19.append(":")) {
                  Entry sb1 = (Entry)var22.next();
                  String i$ = HatHandler.getNameForHat((String)sb1.getKey());
                  var19.append(i$);
                  if(((Integer)sb1.getValue()).intValue() > 1) {
                     var19.append(">" + sb1.getValue());
                  }
               }

               NBTTagCompound var24 = var17.trader1.getEntityData().getCompoundTag("PlayerPersisted");
               var24.setString("Hats_unlocked", var19.toString().length() > 0?var19.toString().substring(0, var19.toString().length() - 1):var19.toString());
               var17.trader1.getEntityData().setTag("PlayerPersisted", var24);
               StringBuilder var25 = new StringBuilder();

               Iterator var23;
               for(var23 = var18.entrySet().iterator(); var23.hasNext(); var25.append(":")) {
                  Entry is = (Entry)var23.next();
                  String hatName = HatHandler.getNameForHat((String)is.getKey());
                  var25.append(hatName);
                  if(((Integer)is.getValue()).intValue() > 1) {
                     var25.append(">" + is.getValue());
                  }
               }

               var24 = var17.trader2.getEntityData().getCompoundTag("PlayerPersisted");
               var24.setString("Hats_unlocked", var25.toString().length() > 0?var25.toString().substring(0, var25.toString().length() - 1):var25.toString());
               var17.trader2.getEntityData().setTag("PlayerPersisted", var24);
               EventHandler.sendPlayerSessionInfo(var17.trader1);
               EventHandler.sendPlayerSessionInfo(var17.trader2);
               this.removeItems(var17.trader1, var17.trader1Items);
               this.removeItems(var17.trader2, var17.trader2Items);
               var23 = var17.trader2Items.iterator();

               ItemStack var26;
               while(var23.hasNext()) {
                  var26 = (ItemStack)var23.next();
                  if(!var17.trader1.inventory.addItemStackToInventory(var26)) {
                     var17.trader1.dropPlayerItemWithRandomChoice(var26, false);
                  }
               }

               var23 = var17.trader1Items.iterator();

               while(var23.hasNext()) {
                  var26 = (ItemStack)var23.next();
                  if(!var17.trader2.inventory.addItemStackToInventory(var26)) {
                     var17.trader2.dropPlayerItemWithRandomChoice(var26, false);
                  }
               }

               PacketHandler.sendToPlayer(Hats.channels, new PacketPing(3, false), var17.trader1);
               PacketHandler.sendToPlayer(Hats.channels, new PacketPing(3, false), var17.trader2);
               var17.terminate = true;
               this.activeTrades.remove(var15);
            } else if(var17.terminate) {
               this.activeTrades.remove(var15);
            }
         }
      }

   }

   public void transferHat(TreeMap origin, TreeMap destination, TreeMap hatsList) {
      HashMap temp = new HashMap();
      Iterator ite = origin.entrySet().iterator();

      Iterator i$;
      Entry e;
      while(ite.hasNext()) {
         Entry ite1 = (Entry)ite.next();
         i$ = hatsList.entrySet().iterator();

         while(i$.hasNext()) {
            e = (Entry)i$.next();
            if(((String)ite1.getKey()).equals(e.getKey())) {
               if(((Integer)ite1.getValue()).intValue() - ((Integer)e.getValue()).intValue() <= 0) {
                  ite.remove();
                  break;
               }

               temp.put(ite1.getKey(), Integer.valueOf(((Integer)ite1.getValue()).intValue() - ((Integer)e.getValue()).intValue()));
            }
         }
      }

      Iterator ite11 = temp.entrySet().iterator();

      Entry i$1;
      while(ite11.hasNext()) {
         i$1 = (Entry)ite11.next();
         origin.put(i$1.getKey(), i$1.getValue());
      }

      temp.clear();
      ite11 = hatsList.entrySet().iterator();

      while(ite11.hasNext()) {
         i$1 = (Entry)ite11.next();
         Iterator e1 = destination.entrySet().iterator();

         while(e1.hasNext()) {
            Entry e1 = (Entry)e1.next();
            if(((String)i$1.getKey()).equals(e1.getKey())) {
               temp.put(e1.getKey(), Integer.valueOf(((Integer)i$1.getValue()).intValue() + ((Integer)e1.getValue()).intValue()));
               ite11.remove();
               break;
            }
         }
      }

      i$ = temp.entrySet().iterator();

      while(i$.hasNext()) {
         e = (Entry)i$.next();
         destination.put(e.getKey(), e.getValue());
      }

      temp.clear();
      i$ = hatsList.entrySet().iterator();

      while(i$.hasNext()) {
         e = (Entry)i$.next();
         destination.put(e.getKey(), e.getValue());
      }

   }

   public void removeItems(EntityPlayer origin, ArrayList itemsList) {
      ArrayList itemsListCopy = new ArrayList();
      Iterator i$ = itemsList.iterator();

      ItemStack is;
      while(i$.hasNext()) {
         is = (ItemStack)i$.next();
         itemsListCopy.add(is.copy());
      }

      int i;
      ItemStack is1;
      for(int var8 = origin.inventory.mainInventory.length - 1; var8 >= 0; --var8) {
         is = origin.inventory.mainInventory[var8];
         if(is != null) {
            for(i = itemsListCopy.size() - 1; i >= 0; --i) {
               is1 = (ItemStack)itemsListCopy.get(i);
               if(is1.isItemEqual(is) && ItemStack.areItemStackTagsEqual(is, is1)) {
                  while(is.stackSize > 0 && is1.stackSize > 0) {
                     --is.stackSize;
                     --is1.stackSize;
                  }

                  if(is1.stackSize <= 0) {
                     itemsListCopy.remove(i);
                  }
               }
            }

            if(is.stackSize <= 0) {
               origin.inventory.mainInventory[var8] = null;
            }

            origin.inventory.markDirty();
         }
      }

      i$ = itemsListCopy.iterator();

      while(i$.hasNext()) {
         is = (ItemStack)i$.next();

         for(i = itemsList.size() - 1; i >= 0; --i) {
            is1 = (ItemStack)itemsList.get(i);
            if(is1.isItemEqual(is) && ItemStack.areItemStackTagsEqual(is, is1)) {
               while(is.stackSize > 0 && is1.stackSize > 0) {
                  --is.stackSize;
                  --is1.stackSize;
               }

               if(is1.stackSize <= 0) {
                  itemsList.remove(i);
               }
            }
         }
      }

   }

   public void playerKilledEntity(EntityLivingBase living, EntityPlayer player) {
      String hat = (String)this.mobHats.get(living);
      RenderOnEntityHelper helper = HatHandler.getRenderHelper(living.getClass());
      if((helper == null || helper.canUnlockHat(living)) && hat != null) {
         HatHandler.unlockHat(player, hat);
      }

      this.mobHats.remove(living);
   }

   public void playerDeath(EntityPlayer player) {
      NBTTagCompound persistentTag = player.getEntityData().getCompoundTag("PlayerPersisted");
      persistentTag.setString("Hats_unlocked", "");
      player.getEntityData().setTag("PlayerPersisted", persistentTag);
      CommonProxy var10000 = Hats.proxy;
      CommonProxy.playerWornHats.put(player.getCommandSenderName(), new HatInfo());
      PacketHandler.sendToPlayer(Hats.channels, new PacketPing(1, false), player);
      Hats.proxy.sendPlayerListOfWornHats(player, false, false);
   }

   public void updateNewKing(String newKing, EntityPlayer player, boolean send) {
      TreeMap hats;
      CommonProxy var10000;
      if(!Hats.config.getSessionString("currentKing").equalsIgnoreCase("") && !Hats.config.getSessionString("currentKing").equalsIgnoreCase(newKing)) {
         EntityPlayerMP sb = FMLCommonHandler.instance().getMinecraftServerInstance().getConfigurationManager().func_152612_a(Hats.config.getSessionString("currentKing"));
         if(sb != null) {
            this.playerDeath(sb);
         }

         var10000 = Hats.proxy;
         hats = CommonProxy.tickHandlerServer.getPlayerHatsList(Hats.config.getSessionString("currentKing"));
         var10000 = Hats.proxy;
         CommonProxy.tickHandlerServer.playerHats.put(Hats.config.getSessionString("currentKing"), (Object)null);
         var10000 = Hats.proxy;
         CommonProxy.tickHandlerServer.playerHats.put(newKing, hats);
      }

      Hats.config.updateSession("currentKing", newKing);
      if(send) {
         if(player != null) {
            if(player.getCommandSenderName().equalsIgnoreCase(Hats.config.getSessionString("currentKing"))) {
               StringBuilder sb1 = new StringBuilder();
               var10000 = Hats.proxy;
               hats = (TreeMap)CommonProxy.tickHandlerServer.playerHats.get(newKing);
               if(hats != null) {
                  for(Iterator i$ = hats.entrySet().iterator(); i$.hasNext(); sb1.append(":")) {
                     Entry e = (Entry)i$.next();
                     sb1.append((String)e.getKey());
                     if(((Integer)e.getValue()).intValue() != 1) {
                        sb1.append(">" + e.getValue());
                     }
                  }
               }

               PacketHandler.sendToPlayer(Hats.channels, new PacketKingOfTheHatInfo(Hats.config.getSessionString("currentKing"), sb1.toString().length() > 0?sb1.toString().substring(0, sb1.toString().length() - 1):sb1.toString()), player);
            } else {
               PacketHandler.sendToPlayer(Hats.channels, new PacketKingOfTheHatInfo(Hats.config.getSessionString("currentKing"), ""), player);
            }
         } else {
            PacketHandler.sendToAll(Hats.channels, new PacketKingOfTheHatInfo(Hats.config.getSessionString("currentKing"), ""));
         }
      }

   }

   public void initializeTrade(EntityPlayerMP player, EntityPlayerMP plyr) {
      if(player != null && plyr != null) {
         this.activeTrades.add((new TradeInfo(player, plyr)).initialize());
      }
   }

   public TreeMap getPlayerHatsList(String player) {
      CommonProxy var10000 = Hats.proxy;
      TreeMap playerHatsList = (TreeMap)CommonProxy.tickHandlerServer.playerHats.get(player);
      if(playerHatsList == null) {
         playerHatsList = new TreeMap();
         var10000 = Hats.proxy;
         CommonProxy.tickHandlerServer.playerHats.put(player, playerHatsList);
      }

      return playerHatsList;
   }
}
